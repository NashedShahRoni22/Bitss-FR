<?php
function generate_suspicious_image($code, $file_path, $line_number) {
    $plugin_dir = plugin_dir_path(__FILE__); // Get the plugin directory path
    $upload_dir = $plugin_dir . 'snapshot'; // Path to the snapshot directory inside the plugin

    // Ensure the snapshot directory exists
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true); // Create snapshot folder if it doesn't exist
    }

    // Get the domain name
    $domain_name = parse_url(home_url(), PHP_URL_HOST);

    // Generate a filename based on domain, date, and time
    $timestamp = date('Y-m-d_H-i-s');
    $file_name = "malware_{$domain_name}_{$timestamp}.png";
    $image_path = $upload_dir . '/' . $file_name;

    // Create the image using GD library
    $image = imagecreatetruecolor(800, 600); // Create a blank image (800x600 px)

    // Set background color (light gray)
    $bg_color = imagecolorallocate($image, 0, 0, 0);
    imagefill($image, 0, 0, $bg_color);

    // Set text color (black)
    $text_color = imagecolorallocate($image, 255, 255, 255);

    // Set font size (GD built-in font, scale 1 to 5)
    $font = 5; // Font size
    $line_height = imagefontheight($font); // Calculate line height based on font size

    // Write the suspicious code to the image
    $lines = explode("\n", $code); // Split code into lines
    $y_position = 10; // Starting Y position
    foreach ($lines as $line) {
        // Limit text length to fit the image width
        $wrapped_line = wordwrap($line, 90, "\n"); // Wrap text to fit approx. 90 characters
        $wrapped_lines = explode("\n", $wrapped_line);

        foreach ($wrapped_lines as $wrapped_line_text) {
            if ($y_position + $line_height > 600) break; // Avoid overflowing
            imagestring($image, $font, 10, $y_position, $wrapped_line_text, $text_color); // Write each line
            $y_position += $line_height + 5; // Move to the next line
        }
    }

    // Save the image as PNG
    imagepng($image, $image_path);
    imagedestroy($image); // Free memory

    return $image_path; // Return the path where the image was saved
}

?>