jQuery(document).ready(function($) {
    function checkRealTimeNeutralization() {
        $.ajax({
            url: neutralizeChecker.ajax_url,
            type: 'POST',
            data: {
                action: 'check_real_time_neutra'
            },
            success: function(response) {
                console.log(response.data); // Log the response from the server
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
            }
        });
    }

    // Run the check every 30 seconds
    setInterval(checkRealTimeNeutralization, 30000); // 30,000 ms = 30 seconds
});
