/* eslint-disable @typescript-eslint/no-unused-vars */
import ContactForm from "./components/ContactForm";
import { IContact } from "./types/misc";

const App = () => {
  const username = "test";
  const password =
    "f0fa8ff85a176f94354968fea3d2e0dda902b68efc53f59a9eafef10404a7a42";
  const smtpjsConfig = {
    SecureToken: "",
    // smtpjs verified email
    From: "",
    // can add multiple ["abc@mail.com", "xyz@mail.com"]
    To: [],
  };
  const credential = {
    username,
    password,
    smtpjsConfig,
  };

  const handleSubmit = (values: IContact) => {
    console.log(values);
  };

  return (
    <div>
      {/* <ContactForm handleSubmit={handleSubmit} /> */}
      <ContactForm handleSubmit={handleSubmit} credential={credential} />
    </div>
  );
};

export default App;
