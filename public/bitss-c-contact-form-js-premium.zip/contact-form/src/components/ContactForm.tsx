import React, { useEffect, useRef, useState } from "react";
import { IContact } from "../types/misc";
import countryJson from "../data/country.json";
import "./contactFormStyles.scss";

let Email: any;

const AlertPopup = ({ message }: { message: string }) => {
  return <div className="alert-popup">{message}</div>;
};

const CatchaToImage = ({ value }: { value: string }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const context = canvas.getContext("2d");
    if (!context) return;

    // Set canvas dimensions
    canvas.width = 60; // Set the width of the canvas
    canvas.height = 25; // Set the height of the canvas

    // Clear the canvas
    context.clearRect(0, 0, canvas.width, canvas.height);

    // Style the text
    context.font = "14px Arial";
    context.fillStyle = "black";

    // Center the text
    const textWidth = context.measureText(value).width;
    const x = (canvas.width - textWidth) / 2;
    const y = canvas.height / 2;

    // Draw the text on the canvas
    context.fillText(value, x, y);
  }, [value]);

  return <canvas ref={canvasRef}></canvas>;
};

const ContactForm = ({
  credential,
  handleSubmit,
}: {
  credential?: {
    username: string;
    password: string;
    smtpjsConfig?: {
      SecureToken: string;
      From: string;
      To: string[];
    };
  };
  handleSubmit: (values: IContact) => void;
}) => {
  const isCredentialExist =
    credential?.username || credential?.password ? true : false;
  const [isCredentialValid, setIsCredentialValid] = useState<boolean>(true);
  const [isMessageValid, setIsMessageValid] = useState<boolean>(true);
  const [isCaptchaValid, setIsCaptchaValid] = useState<boolean>(true);
  const [isSuspicious, setIsSuspicious] = useState<boolean>(false);
  const [captcha1] = useState<number>(Math.floor(Math.random() * 26) + 6);
  const [captcha2] = useState<number>(Math.floor(Math.random() * 26) + 6);
  const [captcha, setCaptcha] = useState<string>("");
  const [formData, setFormData] = useState<IContact>({
    name: "",
    email: "",
    phone: "",
    country: "",
    subject: "",
    message: "",
  });
  const [formLoadTime, setFormLoadTime] = useState(new Date().getTime());
  const [alertMessage, setAlertMessage] = useState<string>("");

  useEffect(() => {
    const script = document.createElement("script");
    script.src = "https://smtpjs.com/v3/smtp.js";
    script.async = true;

    script.onload = () => {
      // Assign the Email object to the global variable
      Email = (window as any).Email;

      // Now you can use Email outside the useEffect
    };

    document.head.appendChild(script);

    // Cleanup to remove the script element when the component unmounts
    return () => {
      document.head.removeChild(script);
    };
  }, []);

  console.log("isCredentialExist", isCredentialExist);
  useEffect(() => {
    setFormLoadTime(new Date().getTime());
    if (isCredentialExist) fetchForbiddenWords();
  }, []);

  const checkSuspiciousActivity = () => {
    const submissionTime = new Date().getTime();
    // Check if the form was submitted within 5 seconds
    if (submissionTime - formLoadTime < 5000) return true;
    return false;
  };

  // Function to check if the message field contains forbidden words
  const checkForbiddenWords = (words: string[] | []) => {
    for (const word of words) {
      if (formData.message.toLowerCase().includes(word.toLowerCase())) {
        console.log("Submission blocked due to link(s) in the message.");
        return true;
      }
    }
    console.log("Submission allowed.");
    return false;
  };

  const fetchForbiddenWords = async () => {
    const apiUrl = "https://bitts.fr/api.php";
    const servername = window.location.hostname;

    const data = {
      username: credential?.username,
      password: credential?.password,
      servername,
    };

    try {
      const response = await fetch(apiUrl, {
        mode: "cors",
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      console.log("response", response);
      if (response.ok) {
        const result = await response.json();
        setIsCaptchaValid(true);
        return result ?? [];
      } else {
        setIsCredentialValid(false);
      }
    } catch (error: any) {
      console.error(error.message);
      setIsCredentialValid(false);
    }
  };

  const showAlert = (message: string) => {
    setAlertMessage(message);
    setTimeout(() => {
      setAlertMessage("");
    }, 3000); // 3000 milliseconds (3 seconds)
  };

  const onSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    // Time difference validate
    const isSuspicious = checkSuspiciousActivity();
    setIsSuspicious(isSuspicious);
    if (isSuspicious) return;

    if (isCredentialExist) {
      // Captcha validation
      const isCaptchaValid = captcha1 + captcha2 === Number(captcha);
      setIsCaptchaValid(isCaptchaValid);
      if (!isCaptchaValid) return;

      // Forbidden words check
      const data = await fetchForbiddenWords();
      const isMessageValid = !checkForbiddenWords(data ?? []);
      setIsMessageValid(isMessageValid);
      if (!isMessageValid) return;

      // send email
      if (credential?.smtpjsConfig?.SecureToken) {
        Email.send({
          ...credential?.smtpjsConfig,
          Subject: formData.subject,
          Body: `<p>
              <strong>Name: </strong>${formData.name} <br>
              <strong>Email: </strong>${formData.email} <br>
              <strong>Phone: </strong>${formData.phone} <br>
              <strong>Country: </strong>${formData.country} <br>
              <strong>Message: </strong>${formData.message} <br>
            </p>`,
        }).then(() => {});
      }
    }

    showAlert("Form submitted successfully!");
    handleSubmit(formData);
  };

  return (
    <div className="container">
      <form onSubmit={onSubmit}>
        <>
          <div>
            <label className="form-title">Name *</label>
            <div>
              <input
                required
                type="text"
                className="form-input"
                value={formData.name}
                onChange={(e) => {
                  setFormData((prev) => ({
                    ...prev,
                    name: e.target.value,
                  }));
                }}
              />
            </div>
          </div>
          <div className="cf-pt-2">
            <label className="form-title">Email *</label>
            <div>
              <input
                required
                type="email"
                className="form-input"
                value={formData.email}
                onChange={(e) => {
                  setFormData((prev) => ({
                    ...prev,
                    email: e.target.value,
                  }));
                }}
              />
            </div>
          </div>
          <div className="cf-pt-2">
            <label className="form-title">Phone *</label>
            <div>
              <input
                required
                type="tel"
                pattern="[0-9]*"
                title="Please enter a valid phone number with only digits (0-9)."
                className="form-input custom-number-input"
                value={formData.phone}
                onChange={(e) => {
                  setFormData((prev) => ({
                    ...prev,
                    phone: e.target.value,
                  }));
                }}
              />
            </div>
          </div>
          <div className="cf-pt-2">
            <label className="form-title">Country *</label>
            <select
              required
              className="form-input"
              defaultValue="DEFAULT"
              onChange={(e) => {
                setFormData((prev) => ({
                  ...prev,
                  country: e.target.value,
                }));
              }}
            >
              <option value="DEFAULT" disabled>
                Please select your country
              </option>
              {countryJson.map((item) => (
                <option key={item.name} value={item.name}>
                  {item.name}
                </option>
              ))}
            </select>
          </div>
          <div className="cf-pt-2">
            <label className="form-title">Subject / Product Query *</label>
            <div>
              <input
                required
                type="text"
                className="form-input"
                value={formData.subject}
                onChange={(e) => {
                  setFormData((prev) => ({
                    ...prev,
                    subject: e.target.value,
                  }));
                }}
              />
            </div>
          </div>
          <div className="cf-pt-2">
            <label className="form-title">Message *</label>
            <div>
              <textarea
                required
                rows={3}
                className="form-input"
                value={formData.message}
                onChange={(e) => {
                  setFormData((prev) => ({
                    ...prev,
                    message: e.target.value,
                  }));
                }}
              />
            </div>
            {!isMessageValid && (
              <div className="invalid-field">
                Submission blocked due to link(s) in the message.
              </div>
            )}
          </div>
          <div className="notes cf-pt-2">
            Note: Before submitting, please ensure that you fill in or select
            all required fields marked by a star (*).
          </div>
          {isSuspicious && (
            <div className="invalid-field cf-pt-2">
              Suspicious activity detected!
            </div>
          )}
          {!isCredentialValid && (
            <div className="invalid-field cf-pt-2">
              Invalid license key. Please active your plugin with a valid
              license key. Purchase a license from bitss.fr or contact
              support@bobosohomail.com.
            </div>
          )}
        </>
        {isCredentialExist && isCredentialValid && (
          <div className="cf-pt-3">
            <label className="form-title">CAPTCHA MATH: *</label>
            <div className="cf-pt-1">
              <div className="captach">
                <CatchaToImage value={`${captcha1} + ${captcha2} = `} />
              </div>
              <input
                required
                type="number"
                className="form-input custom-number-input"
                value={captcha}
                onChange={(e) => {
                  setCaptcha(e.target.value);
                }}
              />
              {!isCaptchaValid && (
                <div className="invalid-field">Captcha is wrong</div>
              )}
            </div>
          </div>
        )}
        <div className="cf-mt-5">
          <button type="submit" className="submit-button">
            SUBMIT
          </button>
        </div>
      </form>
      {alertMessage && <AlertPopup message={alertMessage} />}
    </div>
  );
};

export default ContactForm;
