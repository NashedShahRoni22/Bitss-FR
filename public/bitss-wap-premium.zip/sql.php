<?php
// Ensure $wpdb is globally accessible
global $wpdb;

// Table creation queries using prepared statements
$table_ip_blacklist = $wpdb->prefix . 'ip_blacklist';
$table_ip_whitelist = $wpdb->prefix . 'ip_whitelist';
$table_ip_admin = $wpdb->prefix . 'ip_admin';

// SQL queries with placeholders for prepared statements
$sql_ip_blacklist = "CREATE TABLE IF NOT EXISTS {$table_ip_blacklist} (
    id INT(11) NOT NULL AUTO_INCREMENT,
    ip_address VARCHAR(45) NOT NULL,
    ip_name VARCHAR(64) DEFAULT 'Unknown',
    ip_count INT(11) NOT NULL,
    attempt_timestamp DATETIME NOT NULL,
    PRIMARY KEY (id)
) {$wpdb->get_charset_collate()};";

$sql_ip_whitelist = "CREATE TABLE IF NOT EXISTS {$table_ip_whitelist} (
    id INT(11) NOT NULL AUTO_INCREMENT,
    ip_address VARCHAR(45) NOT NULL,
    ip_name VARCHAR(64) DEFAULT 'Unknown',
    ip_count INT(11) NOT NULL,
    attempt_timestamp DATETIME NOT NULL,
    PRIMARY KEY (id)
) {$wpdb->get_charset_collate()};";

$sql_ip_admin = "CREATE TABLE IF NOT EXISTS {$table_ip_admin} (
    id INT(11) NOT NULL AUTO_INCREMENT,
    ip_address VARCHAR(45) NOT NULL,
    ip_name VARCHAR(64) NOT NULL,
    valid_till DATETIME NOT NULL,
    failed_login_count INT(11) NOT NULL,
    attempt_timestamp DATETIME NOT NULL,
    PRIMARY KEY (id)
) {$wpdb->get_charset_collate()};";

// Execute the queries
$wpdb->query($sql_ip_blacklist);
$wpdb->query($sql_ip_whitelist);
$wpdb->query($sql_ip_admin);

