jQuery(document).ready(function($) {
    $('#bfin-contact-form').submit(function(e) {
        e.preventDefault();

        var $form = $(this);
        var $messageElement = $('#bfin-contact-form-message');
        var formData = $form.serialize();

        $.ajax({
            type: 'POST',
            url: contactFormAjax.ajaxUrl,
            data: formData + '&action=submit_bitss_contact_form_ajax',
            beforeSend: function() {
                // Show a loading message or spinner if desired
                $messageElement.text('Submitting...');
            },
            success: function(response) {
                if (response.success) {
                    // Display success message
                    $messageElement.removeClass('error').addClass('success').text(response.data);
                    $form[0].reset(); // Reset the form fields if needed
                } else {
                    // Display error message
                    $messageElement.removeClass('success').addClass('error').text(response.data);
                }
            },
            error: function() {
                // Display error message
                $messageElement.removeClass('success').addClass('error').text('An error occurred while submitting the form.');
            },
            complete: function() {
                // Scroll to the message element
                $('html, body').animate({
                    scrollTop: $messageElement.offset().top - 50
                }, 500);
            }
        });
    });
});
