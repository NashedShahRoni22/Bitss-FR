# Bitss Simple Contact Form

This package provides a simple ContactForm component with free and paid version.

## Usage Manual

Just import the ContactForm component. credential props is optional until you're a paid user with username and password.

- In your component:

```js
// put your username
const username = "";
// put your password
const password = "";

// use smtpjs to get notified through mail
const smtpjsConfig = {
  SecureToken: "",
  // smtpjs verified email
  From: "",
  // can add multiple ["abc@mail.com", "xyz@mail.com"]
  To: [],
};

const credential = {
  username,
  password,
  smtpjsConfig,
};

const handleSubmit = (values) => {
  console.log(values);
};

<ContactForm handleSubmit={handleSubmit} credential={credential} />;
```

- Do not forget to link the css in your "index.html"

```
<link rel="stylesheet" href="node_modules/bitss-contact-form/dist/style.css" />
```
