<?php
/*
Plugin Name: BITSS Secure Contact Form
Plugin URI: https://bitss.fr/
Description: BITSS Secure Contact Form by BFIN.
Version: 1.0
Author: BFIN
Author URI: https://bfin.company/
License: GPLv2 or later
*/


class BITSSContactForm
{
	public function __construct()
	{
		add_shortcode('bitss_contact_form', [$this, 'render_contact_form']);
		add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
		add_action('admin_post_nopriv_custom_contact_form_submit', [$this, 'handle_form_submission']);
		add_action('admin_post_custom_contact_form_submit', [$this, 'handle_form_submission']);
		add_action('wp_ajax_submit_bitss_contact_form_ajax', [$this, 'handle_form_submission_ajax']);
		add_action('wp_ajax_nopriv_submit_bitss_contact_form_ajax', [$this, 'handle_form_submission_ajax']);
		add_action('admin_menu', array($this, 'add_settings_page'));
		add_action('admin_init', array($this, 'register_settings'));
		add_action('admin_post_bitsscf_save_settings', [$this, 'handle_settings_form_submission']);
		add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
	}

	public function render_contact_form($atts)
	{
		ob_start();
		include 'templates/contact-form.php';
		$form_content = ob_get_clean();
		return $form_content;
	}

	private function get_plugin_url()
	{
		return 'https://bfin.company';
	}

	public function enqueue_scripts()
	{
		wp_enqueue_style('contact-form-styles', plugins_url('css/styles.css', __FILE__));
		wp_enqueue_script('contact-form-script', plugins_url('js/script.js', __FILE__), ['jquery'], null, true);
		wp_localize_script('contact-form-script', 'contactFormAjax', [
			'ajaxUrl' => admin_url('admin-ajax.php'),
			'redirectUrl' => home_url(),
		]);
	}
	public function enqueue_admin_scripts()
	{
		wp_enqueue_style('bitsscf-plugin-styles', plugins_url('css/stylesAdmin.css', __FILE__));
	}
	
	

	public function handle_form_submission()
	{
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$name = sanitize_text_field($_POST['name']);
			$email = sanitize_email($_POST['email']);
			$phone = sanitize_text_field($_POST['phone']);
			$country = sanitize_text_field($_POST['country']);
			$subject = sanitize_text_field($_POST['subject']);
			$message = sanitize_textarea_field($_POST['message']);
			if (empty($name) || empty($email) || empty($phone) || empty($country) || empty($subject) || empty($message)) {
				wp_send_json_error('Please make sure that you fill/select all required fields.');
			}
			$apiUrl = 'https://bitts.fr/api.php';
			$username = get_option('bfin_api_username');
			$password = get_option('bfin_api_password');
			$servername = $_SERVER['SERVER_NAME'];
			$data = array(
				'username' => $username,
				'password' => $password,
				'servername' => $servername,
			);
			$ch = curl_init($apiUrl);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
			$response = curl_exec($ch);
			if ($response === false) {
				echo 'Error: ' . curl_error($ch);
			}
			curl_close($ch);
			$forbiddenWords = json_decode($response, true);
			if (empty($forbiddenWords)) {
				wp_send_json_error('Error fetching forbidden words from the API.');
			}
			foreach ($forbiddenWords as $word) {
				if (stripos($message, $word) !== false) {
					wp_send_json_error('Submission blocked due to link(s) in the message.');
				}
			}
			$to = get_option('admin_email');
			$subject = $subject;
			$websiteName = home_url();
			$headers = array('Content-Type: text/html; charset=UTF-8', "From: $name <$email>");
			$ipAddress = $_SERVER['REMOTE_ADDR'];
			$userAgent = $_SERVER['HTTP_USER_AGENT'];
			if (!empty($username) || !empty($password)) {
				$warning = 'To maximise your cyber security consider upgrading to bitss WP for full database protection and maximise your cyber secuity overall. Please <a href="https://bitss.fr">click here</a> for more details.';
			} else {
				$warning = 'Users receiving spam should consider upgarding to Bitss C antispam for contact and protect your contact page against all types of spam. For upgrade, please <a href="https://bitss.fr">click here</a>.';
			}
			$body = "<!DOCTYPE html><html><head> <meta charset=\"utf-8\"> <title>New Contact Form Submission</title> <style> body { font-family: Arial, sans-serif; background-color: #f5f5f5; margin: 30px 0; padding: 30px 0; } .container { max-width: 600px; margin: 0 auto; padding: 30px 50px; background-color: #ffffff; border-radius: 4px; box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1); } h1 { color: #333333; font-size: 24px; margin-bottom: 20px; text-align: center; border-bottom: 1px solid #eee; padding-bottom: 20px; } table { width: 100%; margin: 20px 0px; } td { padding: 5px 0px; } .footer { font-size: 14px; color: #999999; margin-top: 20px; } .warninginfo {text-align:center;} </style></head><body> <div class=\"container\"> <h1>New Contact Form Submission</h1> <p>Hello Admin,</p> <p>You have received a new contact form submission with the following details:</p> <table> <tr><td><strong>Name:</strong> $name</td> </tr> <tr><td><strong>Email:</strong> $email</td> </tr> <tr><td><strong>Phone:</strong> $phone</td> </tr> <tr><td><strong>Country:</strong> $country</td> </tr> <tr><td><strong>Subject:</strong> $subject</td> </tr> <tr><td><strong>Message:</strong></td> </tr> <tr><td>$message</td> </tr>
			<tr><td><strong>IP:</strong></td> </tr> <tr><td><a href=\"https://iplocation.io/ip/$ipAddress\">$ipAddress</a></td> </tr>
			<tr><td><strong>User Agent:</strong></td> </tr> <tr><td>$userAgent</td> </tr>
			<tr><td>Click on ip to get some approximate details about sender ip.</td> </tr>
			</table> <p>Please take the necessary action and respond to the contact as soon as possible.</p> <p class=\"footer\">Thank you!<br>$websiteName</p><br><p class=\"warninginfo\">$warning</p></div></body></html>";
			$sent = wp_mail($to, $subject, $body, $headers);
			if ($sent) {
				wp_send_json_success('Your message has been successfully submitted. We appreciate your interest and will respond to you as soon as possible.');
			} else {
				wp_send_json_error('An error occurred while sending the message.');
			}
		}
	}
	public function handle_form_submission_ajax()
	{
		$this->handle_form_submission();
		wp_die();
	}
	public function add_settings_page()
	{
		add_options_page(
			'BITSS Contact Form Settings',
			'BITSS CF Settings',
			'manage_options',
			'bitsscf-settings',
			array($this, 'render_settings_page')
		);
	}
	public function register_settings()
	{
		register_setting('bitsscf_plugin_group', 'bitsscf_option_name');
		register_setting('bitsscf_plugin_group', 'bfin_api_username');
		register_setting('bitsscf_plugin_group', 'bfin_api_password');
		register_setting('bitsscf_plugin_group', 'bfin_api_power');
	}
	public function render_settings_page()
	{
?>
		<div class="wrap my-3">
			<div class="mb-3">
				<h3 class="text-bold">BITSS CF License Settings</h3>
			</div>
			<div class="cfsettingscss">
				<form method="post" action="options.php">
					<input type="hidden" name="action" value="bitsscf_save_settings">
					<?php
					settings_fields('bitsscf_plugin_group');
					do_settings_sections('bitsscf-plugin-settings');
					?>
					<div class="mb-3">
						<p><strong>Note:</strong> Without license you can easily use contact form. To use this form use our shortcode <strong>[bitss_contact_form]</strong> in your template. If you put any invalid key or username, it won't show any error but may occur in contact form performance. Thanks.</p>
					</div>
					<div class="mb-3">
						<label for="bfin_api_username" class="form-label">License Username:</label>
						<input class="admin form-control" type="text" name="bfin_api_username" id="bfin_api_username" value="<?php echo esc_attr(get_option('bfin_api_username')); ?>">
					</div>
					<div class="mb-3">
						<label for="bfin_api_password" class="form-label">License Key:</label>
						<input class="admin form-control" type="text" name="bfin_api_password" id="bfin_api_password" value="<?php echo esc_attr(get_option('bfin_api_password')); ?>">
					</div>
					<div class="mb-3">
						<input 
							class="form-check-input" 
							name="bfin_api_power" 
							type="checkbox" 
							value="1"
							id="bfin_api_power" 
							<?php checked(get_option('bfin_api_power'), 1); ?>
						>
						<label 
							class="form-check-label" 
							for="bfin_api_power"
						>
							Would you like to display the "Powered by" message below?
						</label>
					</div>
				
					<div class="submitbutton">
						<?php
						submit_button('Save Settings');
						?>
					</div>
				</form>
			</div>
		</div>
<?php
	}
}
$bfin_contact_form_plugin = new BITSSContactForm();

$valuecheck = esc_attr(get_option('bfin_api_power'));
if ($valuecheck == 1) {
	function credit_info() {
		?>
		<small>&copy; <?php echo date('Y'); ?> BFIN. BITSS by BFIN. All rights reserved.</small><br>
		<small class="credit" style="display:flex!important;align-items:center!important">This form is powered by 
			<a href="https://bitss.fr" target="_blank" rel="nofollow">
				<img src="<?php echo plugin_dir_url(__FILE__) . 'bitss_icon.png'; ?>" width="40">
			</a>
		</small>
		<?php
	}
} else {
	function credit_info() {
		
	}
}
