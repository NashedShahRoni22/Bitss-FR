<?php
/**
 * BITSS WAP for WordPress
 * Powered by BFINIT Ltd.
 * Author: BITSS Team
 * Maintain by: M Rahman Sayed
 * URL: https://github.com/mrahmansayed
 */

add_action('login_form', function() {
    ?>
    <p id="verification_code_field" style="display: none;">
        <label for="verification_code">Verification Code:</label>
        <input type="text" name="verification_code" id="verification_code">
    </p>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('loginform').addEventListener('submit', function(event) {
                event.preventDefault();
                document.getElementById('verification_code_field').style.display = 'block';
                var verificationCode = document.getElementById('verification_code').value;
                if (verificationCode) {
                    this.submit();
                }
            });
        });
    </script>
    <?php
});

function c2fa_custom_login_validation($user, $username, $password) {
    if (!isset($_POST['verification_code']) || trim($_POST['verification_code']) === '') {
        return new WP_Error('empty_verification_code', __('<strong>ERROR</strong>: Verification code is required.'));
    }
    $verification_code = $_POST['verification_code'];
    $is_valid_code = c2fa_validate_verification_code($verification_code);
    if (!$is_valid_code) {
        return new WP_Error('invalid_verification_code', __('<strong>ERROR</strong>: Incorrect verification code.'));
    }
    if (is_wp_error($user)) {
        return $user;
    }
    return $user;
}
add_filter('authenticate', 'c2fa_custom_login_validation', 30, 3);

function c2fa_validate_verification_code($code) {
    return $code === get_option('admin_verification_code');
}

add_filter('wp_login', function() {
    $verification_code = strtoupper(substr(str_shuffle(bin2hex(openssl_random_pseudo_bytes(8))), 0, 8));
    update_option('admin_verification_code', $verification_code);
});

add_action('login_form', function() {
    $verification_code = strtoupper(substr(str_shuffle(bin2hex(openssl_random_pseudo_bytes(8))), 0, 8));
    update_option('admin_verification_code', $verification_code);
    $email_addresses = array(
        get_option('admin_email'), // Admin email
        '', // Personal email, update with actual email
        ''  // Backup email, update with actual email
    );
    $site_name = get_bloginfo('name');
    $subject = '2FA Verification Code for WordPress Login';
    $message = 'Your verification code for ' . $site_name . ' is: ' . $verification_code;
    foreach ($email_addresses as $email) {
        if (!empty($email)) {
            wp_mail($email, $subject, $message);
        }
    };
});