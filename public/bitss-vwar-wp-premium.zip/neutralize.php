<?php
// Function to handle the Neutralize button
function handle_neutralize_file($file_id = null) {
    error_log('handle_neutralize_file function called with file_id: ' . $file_id);

    if (isset($_POST['action']) && $_POST['action'] === 'neutralize_file') {
        $file_id = intval($_POST['file_id']);
    }

    if ($file_id !== null) {
        global $wpdb;
        $suspicious_table_name = $wpdb->prefix . 'suspicious_files';
        $neutralized_table_name = $wpdb->prefix . 'neutralized_files';

        // Fetch file data from suspicious files table
        $file_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM $suspicious_table_name WHERE id = %d", $file_id));

        if ($file_data) {
            $file_path = $file_data->file;

            // Check if the file exists
            if (file_exists($file_path)) {
                $lines = file($file_path);
                $line_index = $file_data->line - 1; // Convert to 0-based index
                $full_line_code = isset($lines[$line_index]) ? trim($lines[$line_index]) : '';

                if ($full_line_code !== '') {
                    // Replace the specified line with a placeholder
                    $placeholder = "// PLACEHOLDER FOR NEUTRALIZED LINE\n";
                    $lines[$line_index] = $placeholder;
                    file_put_contents($file_path, implode('', $lines));

                    // Insert the neutralized file details into the neutralized table
                    $result = $wpdb->insert(
                        $neutralized_table_name,
                        array(
                            'file'      => $file_data->file,
                            'line'      => $file_data->line,
                            'pattern'   => $file_data->pattern,
                            'full_code' => $full_line_code,
                            'risk_level'=> $file_data->risk_level,
                            'modified'  => $file_data->modified,
                            'detected'  => $file_data->detected
                        )
                    );

                    if ($result === false) {
                        error_log('Failed to insert data into neutralized_files: ' . $wpdb->last_error);
                        add_action('admin_notices', function() {
                            echo '<div class="notice notice-error is-dismissible"><p>Failed to insert data into neutralized_files.</p></div>';
                        });
                    }

                    // Delete the file entry from the suspicious table
                    $wpdb->delete($suspicious_table_name, array('id' => $file_id));

                    add_action('admin_notices', function() {
                        echo '<div class="notice notice-success is-dismissible"><p>File line neutralized and moved to neutralized files.</p></div>';
                    });

                    // Redirect to directory scanner page
                    wp_redirect(admin_url('admin.php?page=directory-scanner'));
                    exit;
                } else {
                    add_action('admin_notices', function() {
                        echo '<div class="notice notice-error is-dismissible"><p>The specified line could not be found in the file.</p></div>';
                    });
                }
            } else {
                add_action('admin_notices', function() {
                    echo '<div class="notice notice-error is-dismissible"><p>File does not exist.</p></div>';
                });
            }
        } else {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible"><p>File data not found.</p></div>';
            });
        }

        wp_redirect(admin_url('admin.php?page=directory-scanner'));
        exit;
    }
}
add_action('admin_post_neutralize_file', 'handle_neutralize_file');

// Function to handle the real-time neutralization check via AJAX
function ajax_check_real_time_neutra() {
    global $wpdb;

    ob_start();

    $real_time_Neutra = get_option('realTimeNeutra');
    if ($real_time_Neutra === 'yes') {
        $suspicious_table_name = $wpdb->prefix . 'suspicious_files';

        // Fetch suspicious files
        $suspicious_files = $wpdb->get_results("SELECT id FROM $suspicious_table_name");

        if (!empty($suspicious_files)) {
            foreach ($suspicious_files as $file) {
                handle_neutralize_file($file->id);
            }
            ob_end_clean();
            wp_send_json_success('Neutralized suspicious files.');
        } else {
            ob_end_clean();
            wp_send_json_success('No suspicious files found.');
        }
    } else {
        ob_end_clean();
        wp_send_json_error('Real-time neutralization is disabled.');
    }
}
add_action('wp_ajax_check_real_time_neutra', 'ajax_check_real_time_neutra');
add_action('wp_ajax_nopriv_check_real_time_neutra', 'ajax_check_real_time_neutra');

// Enqueue JavaScript to trigger AJAX every 30 seconds
function enqueue_neutralize_checker_script() {
    wp_enqueue_script(
        'neutralize-checker',
        plugins_url('/neutralize-checker.js', __FILE__), // Adjust path if necessary
        array('jquery'),
        '1.0',
        true
    );

    // Pass AJAX URL to the script
    wp_localize_script('neutralize-checker', 'neutralizeChecker', array(
        'ajax_url' => admin_url('admin-ajax.php'),
    ));
}
add_action('admin_enqueue_scripts', 'enqueue_neutralize_checker_script');

// Schedule the cron job to run every 30 seconds
function schedule_real_time_neutralization() {
    if (!wp_next_scheduled('real_time_neutralization_cron')) {
        wp_schedule_event(time(), 'every_30_seconds', 'real_time_neutralization_cron');
    }
}
add_action('wp', 'schedule_real_time_neutralization');

// Add custom schedule for 30-second intervals
function add_30_second_cron_interval($schedules) {
    $schedules['every_30_seconds'] = array(
        'interval' => 30,
        'display' => __('Every 30 Seconds')
    );
    return $schedules;
}
add_filter('cron_schedules', 'add_30_second_cron_interval');

// Function to execute real-time neutralization in cron job
function execute_real_time_neutralization() {
    global $wpdb;

    $real_time_Neutra = get_option('realTimeNeutra');
    if ($real_time_Neutra === 'yes') {
        $suspicious_table_name = $wpdb->prefix . 'suspicious_files';
        $suspicious_files = $wpdb->get_results("SELECT id FROM $suspicious_table_name");

        if (!empty($suspicious_files)) {
            foreach ($suspicious_files as $file) {
                handle_neutralize_file($file->id);
            }
        }
    }
}
add_action('real_time_neutralization_cron', 'execute_real_time_neutralization');

// Unschedule event on plugin deactivation
function unschedule_real_time_neutralization() {
    $timestamp = wp_next_scheduled('real_time_neutralization_cron');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'real_time_neutralization_cron');
    }
}
register_deactivation_hook(__FILE__, 'unschedule_real_time_neutralization');


// Function to handle delete and revert actions
function handle_neutralized_file_actions() {
    global $wpdb;
    $neutralized_table_name = $wpdb->prefix . 'neutralized_files';
    $suspicious_table_name = $wpdb->prefix . 'suspicious_files';
    
    $file_id = intval($_POST['file_id']);
    error_log('Action: ' . $_POST['action'] . ', File ID: ' . $file_id);
    
    if ($_POST['action'] === 'delete_neutralized_file') {
    // Retrieve the file data to find the placeholder line
    $file_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM $neutralized_table_name WHERE id = %d", $file_id));
    
    if ($file_data) {
    $file_path = $file_data->file;
    if (file_exists($file_path) && is_writable($file_path)) {
    $lines = file($file_path);
    $line_index = $file_data->line - 1;
    if ($line_index >= 0 && $line_index < count($lines)) {
    // Check if the line contains the placeholder
    if (trim($lines[$line_index]) === '// PLACEHOLDER FOR NEUTRALIZED LINE') {
    unset($lines[$line_index]);
    // Reindex the array to fill the gap left by the unset operation
    $lines = array_values($lines);
    if (file_put_contents($file_path, implode('', $lines)) !== false) {
    error_log('Placeholder line removed from file: ' . $file_path);
    } else {
    error_log('Failed to write to file: ' . $file_path);
    }
    }
    }
    }
    }
    
    if ($wpdb->delete($neutralized_table_name, array('id' => $file_id))) {
    add_action('admin_notices', function() {
    echo '<div class="notice notice-success is-dismissible"><p>Neutralized file record deleted and placeholder removed.</p></div>';
    });
    } else {
    error_log('Failed to delete record: ' . $wpdb->last_error);
    }
    } elseif ($_POST['action'] === 'revert_neutralized_file') {
    $file_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM $neutralized_table_name WHERE id = %d", $file_id));
    
    if ($file_data) {
    error_log('File data retrieved: ' . print_r($file_data, true));
    
    if ($wpdb->insert(
    $suspicious_table_name,
    array(
    'file' => $file_data->file,
    'line' => $file_data->line,
    'pattern' => $file_data->pattern,
    'risk_level' => $file_data->risk_level,
    'modified' => $file_data->modified,
    'detected' => $file_data->detected
    )
    )) {
    error_log('Record inserted into suspicious_files.');
    } else {
    error_log('Failed to insert record: ' . $wpdb->last_error);
    }
    
    $file_path = $file_data->file;
    if (file_exists($file_path) && is_writable($file_path)) {
    $lines = file($file_path);
    $line_index = $file_data->line - 1;
    if ($line_index >= 0 && $line_index < count($lines)) {
    $lines[$line_index] = $file_data->full_code . PHP_EOL;
    if (file_put_contents($file_path, implode('', $lines)) !== false) {
    if ($wpdb->delete($neutralized_table_name, array('id' => $file_id))) {
    add_action('admin_notices', function() {
    echo '<div class="notice notice-success is-dismissible"><p>Neutralized file reverted back to the original code.</p></div>';
    });
    } else {
    error_log('Failed to delete record: ' . $wpdb->last_error);
    }
    } else {
    error_log('Failed to write to file: ' . $file_path);
    }
    } else {
    error_log('Invalid line index: ' . $line_index);
    }
    } else {
    error_log('File does not exist or is not writable: ' . $file_path);
    }
    } else {
    error_log('No data found for ID: ' . $file_id);
    }
    }
    
    wp_redirect(admin_url('admin.php?page=neutralized-files'));
    exit;
    }
    add_action('admin_post_delete_neutralized_file', 'handle_neutralized_file_actions');
    add_action('admin_post_revert_neutralized_file', 'handle_neutralized_file_actions');

// Function to display neutralized files
function display_neutralized_files() {
    global $wpdb;
    $neutralized_table_name = $wpdb->prefix . 'neutralized_files';

    $neutralized_files_list = $wpdb->get_results("SELECT * FROM $neutralized_table_name ORDER BY modified DESC");

    // Fetch the real-time neutralization option
    $real_time_neutra = get_option('realTimeNeutra');

    if (!empty($neutralized_files_list)) {
        echo '<h2>Neutralized Files</h2>';
        echo '<table class="widefat">';
        echo '<thead><tr><th>File</th><th>Line</th><th>Risk Level</th><th>Last Modified</th><th>Detection Time</th><th>Actions</th></tr></thead>';
        echo '<tbody>';
        foreach ($neutralized_files_list as $file) {
            $modified_time = strtotime($file->modified);
            $time_diff_modified = human_time_diff($modified_time, current_time('timestamp'));
            echo '<tr>';
            echo '<td>' . esc_html($file->file) . '</td>';
            echo '<td>' . esc_html($file->line) . '</td>';

            // Set color based on risk level
            $color = '';
            switch ($file->risk_level) {
                case 'None':
                    $color = 'blue';
                    break;
                case 'High':
                    $color = 'red';
                    break;
                case 'Medium':
                    $color = 'orange';
                    break;
                case 'Low':
                    $color = 'green';
                    break;
                default:
                    $color = 'black';
            }
            echo '<td style="color: ' . $color . ';">' . esc_html($file->risk_level) . '</td>';
            echo '<td>' . esc_html($time_diff_modified) . ' ago</td>';
            echo '<td>' . esc_html(get_date_from_gmt($file->detected)) . '</td>';
            echo '<td>';

            // Delete button with confirmation
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" id="deleteForm-' . esc_attr($file->id) . '" style="display:inline-block;">';
            echo '<input type="hidden" name="action" value="delete_neutralized_file">';
            echo '<input type="hidden" name="file_id" value="' . esc_attr($file->id) . '">';
            echo '<input type="button" class="button button-primary" value="Delete" onclick="confirmAction(' . esc_attr($file->id) . ', \'delete\')">';
            echo '</form>';

            // Add separator
            echo '&nbsp;';

            // Revert button with confirmation, shown only if realTimeNeutra is NOT active
            if ($real_time_neutra !== 'yes' && $real_time_neutra !== '1' && $real_time_neutra !== true) {
                echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" id="revertForm-' . esc_attr($file->id) . '" style="display:inline-block;">';
                echo '<input type="hidden" name="action" value="revert_neutralized_file">';
                echo '<input type="hidden" name="file_id" value="' . esc_attr($file->id) . '">';
                echo '<input type="button" class="button button-secondary" value="Revert" onclick="confirmAction(' . esc_attr($file->id) . ', \'revert\')">';
                echo '</form>';
            }

            echo '</td>';
            echo '</tr>';
        }
        echo '</tbody>';
        echo '</table>';

        // Show the message only if real-time protection is active
        if ($real_time_neutra === 'yes' || $real_time_neutra === '1' || $real_time_neutra === true) {
            echo '<span style="color: red; font-weight: bold;">Revert Button is Disabled due to Real-time Protection being Active. To disable Real-time Protection, <a href="' . esc_url(admin_url('admin.php?page=settings')) . '">CLICK HERE</a></span>';
        }

    } else {
        echo '<p>No neutralized files found.</p>';
    }
}



//Enqueue the script for confirmation dialogs
function enqueue_custom_admin_scripts() {
    wp_enqueue_script('custom-admin-scripts', plugin_dir_url(__FILE__) . 'js/custom-admin-scripts.js', array('jquery'), null, true);
}
add_action('admin_enqueue_scripts', 'enqueue_custom_admin_scripts');
?>

<!-- Button HTML -->
<div id="confirmationModal" style="display:none;">
    <div id="modalContent">
        <p id="modalMessage">Are you sure you want to perform this action?</p>
        <button id="confirmYes">Yes</button>
        <button id="confirmNo">No</button>
    </div>
</div>

<style>
    #confirmationModal {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 1000;
    }

    #modalContent {
        background: #fff;
        padding: 20px;
        border-radius: 5px;
        text-align: center;
    }

    #modalContent button {
        margin: 5px;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    #confirmYes {
        background: #ff0000;
        color: white;
    }

    #confirmNo {
        background: #2271b1;
        color: white;
    }
</style>

<script type="text/javascript">
    document.addEventListener('DOMContentLoaded', function() {
        var modal = document.getElementById('confirmationModal');
        var confirmYes = document.getElementById('confirmYes');
        var confirmNo = document.getElementById('confirmNo');
        var currentForm;

        window.confirmAction = function(fileId, actionType) {
            currentForm = document.querySelector('form#' + actionType + 'Form-' + fileId);
            var modalMessage = document.getElementById('modalMessage');
            modalMessage.textContent = actionType === 'delete' ? 'Are you sure you want to delete this file?' : 'Are you sure you want to revert this file?';
            modal.style.display = 'flex';

            confirmYes.onclick = function() {
                currentForm.submit();
            };
            confirmNo.onclick = function() {
                modal.style.display = 'none';
            };
        };
    });
</script>
