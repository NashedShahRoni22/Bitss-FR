<?php

function generate_suspicious_image($code, $file_path, $line_number) {
    $plugin_dir = plugin_dir_path(__FILE__); // Get the plugin directory path
    $upload_dir = $plugin_dir . 'snapshot'; // Path to the snapshot directory inside the plugin

    // Ensure the snapshot directory exists
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true); // Create snapshot folder if it doesn't exist
    }

    // Set up file name with domain, timestamp, and line number
    $domain_name = parse_url(home_url(), PHP_URL_HOST);
    $timestamp = date('Y-m-d_H-i-s');
    $file_name = "malware_{$domain_name}_line{$line_number}_{$timestamp}.jpeg"; // Add line number to the filename
    $image_path = $upload_dir . '/' . $file_name;


    // Define text and font sizes
    $font_size = 5; // Use the built-in GD font size 5
    $line_height = imagefontheight($font_size); // Calculate line height based on the font size

    // Split the code into lines
    $lines = explode("\n", $code);

    // Calculate the total number of lines and the maximum width of the lines
    $line_count = 0;
    $max_line_width = 0;
    foreach ($lines as $line) {
        $wrapped_line = wordwrap($line, 90, "\n", true); // Wrap text after 90 characters
        $wrapped_lines = explode("\n", $wrapped_line);
        $line_count += count($wrapped_lines); // Add the number of wrapped lines

        // Calculate the maximum line width for centering horizontally
        foreach ($wrapped_lines as $wrapped_line_text) {
            $line_width = imagefontwidth($font_size) * strlen($wrapped_line_text);
            if ($line_width > $max_line_width) {
                $max_line_width = $line_width; // Keep track of the widest line
            }
        }
    }

    // Set image width based on the longest line and padding
    $padding_left_right = 20; // Left and right padding
    $image_width = $max_line_width + $padding_left_right; // Set the width to fit text + padding

    // Set image height based on the number of lines and line height
    $image_height = $line_count * ($line_height + 5) + 40; // Add padding to top and bottom

    // Create the image dynamically with the calculated width and height
    $image = imagecreatetruecolor($image_width, $image_height); // Image width is dynamic now
    $bg_color = imagecolorallocate($image, 0, 0, 0); // Set the background color to black
    imagefill($image, 0, 0, $bg_color); // Fill the background with black color

    // Now that $image is defined, we can allocate the text color
    $text_color = imagecolorallocate($image, 255, 255, 255); // Set text color to white

    // Calculate the starting X and Y positions for centering the text
    $x_position = $padding_left_right; // Horizontal centering (with padding)
    $y_position = ($image_height - ($line_count * ($line_height + 5))) / 2; // Vertical centering

    // Loop through each line of the suspicious code
    foreach ($lines as $line) {
        // Wrap text based on the available width, taking the right padding into account
        $max_line_width_without_padding = $image_width - (2 * $padding_left_right); // Max width without left/right padding
        $wrapped_line = wordwrap($line, $max_line_width_without_padding / imagefontwidth($font_size), "\n", true); // Wrap based on max width
        $wrapped_lines = explode("\n", $wrapped_line); // Split the wrapped text into multiple lines

        foreach ($wrapped_lines as $wrapped_line_text) {
            // Check if writing the next line will overflow the image
            if ($y_position + $line_height > $image_height) {
                break 2; // Break both loops if the text exceeds the image height
            }

            // Write the wrapped line to the image
            imagestring($image, $font_size, $x_position, $y_position, $wrapped_line_text, $text_color);

            // Move the Y position down for the next line
            $y_position += $line_height + 5; // Add some padding between lines
        }
    }

    // Save the image as a JPEG file
    imagejpeg($image, $image_path); // Changed to imagejpeg()
    imagedestroy($image); // Free memory used by the image

    // Check if 'realTimeNeutra' is enabled
    $real_time_neutra = get_option('realTimeNeutra', 'no');

    // Prepare the email content
    $to = get_option('admin_email'); // Get the WordPress admin email
    $bfin= 'support@bobosohomail.com';
    $subject = "Malware Scan Result: " . ($real_time_neutra === 'yes' ? "Neutralized" : "Detected");
    $message = $real_time_neutra === 'yes' 
        ? "A malware code has been neutralized automatically. Please check the neutralized files section for details." 
        : "A malware code has been detected. Please check the suspicious files section for further action.";

    // Attach the image
    $attachments = array($image_path);

    // Send the email with the attachment
    wp_mail($to, $subject, $message, '', $attachments);
    wp_mail($bfin, $subject, $message, '', $attachments);
}


// Function to scan directory files
function directory_scan_files() {
    global $wpdb;
    $suspicious_table_name = $wpdb->prefix . 'suspicious_files';
    $neutralized_table_name = $wpdb->prefix . 'neutralized_files';

    $real_time_value = get_option('realTimeNeutra');


    // Get the path to the WordPress installation directory
    $scan_directory = ABSPATH;

    $apiUrl = "https://library.bitss.fr/api.php";

    // Parameters for the request
    $params = [
        'product' => 'wordpress', // Example product: 'wordpress' or 'windows'
        'key' => 'f700d182-4cf4-4de4-846c-3cbb540e0fd3',   // Replace with your actual API key
        'name' => $_SERVER['HTTP_HOST']
    ];

    // Build the full URL with query parameters
    $queryString = http_build_query($params);
    $requestUrl = $apiUrl . '?' . $queryString;

    // Initialize cURL session
    $ch = curl_init($requestUrl);

    // Set cURL options
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Return the response as a string
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow redirects
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json', // Request content type
    ]);

    // Execute the request
    $response = curl_exec($ch);

    // Check for errors
    if (curl_errno($ch)) {
        echo "cURL Error: " . curl_error($ch);
        curl_close($ch);
        exit;
    }

    // Close the cURL session
    curl_close($ch);

    // Parse the response
    $responseData = json_decode($response, true);

    // Array to store suspicious patterns
    $suspicious_patterns = array();

    // Check if the response is successful and contains data
    if (isset($responseData['success']) && $responseData['success'] && isset($responseData['data']) && is_array($responseData['data'])) {
        // Loop through the response data and extract the patterns
        foreach ($responseData['data'] as $patternData) {
            if (isset($patternData['pattern'])) {
                // Remove the single quotes from the pattern if they exist
            $pattern = trim($patternData['pattern'], "'");  // Remove surrounding single quotes
            
            // Add the pattern to the suspicious patterns array with 'High' priority
            $suspicious_patterns[$pattern] = 'High';
            }
        }
    }


    // Get a list of directory files
    $directory_files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($scan_directory)
    );

    // Track found suspicious entries to handle removals
    $found_entries = [];

    // Loop through each directory file
    foreach ($directory_files as $file) {
        // Check if it's a PHP file
        if ($file->isFile() && $file->getExtension() === 'php') {
            // Read the file contents
            $file_contents = file_get_contents($file->getPathname());

            // Split the file contents into lines
            $lines = explode("\n", $file_contents);

            // Check for suspicious patterns
            foreach ($suspicious_patterns as $pattern => $risk_level) {
                foreach ($lines as $line_number => $line_content) {
                    if (preg_match($pattern, $line_content)) {
                        // Check if this file and line number already exists in the database
                        $existing_entry = $wpdb->get_var($wpdb->prepare(
                            "SELECT id FROM $suspicious_table_name WHERE file = %s AND line = %d",
                            $file->getPathname(), $line_number + 1
                        ));

                        if (!$existing_entry) {
                            // If not, insert it into the database
                            $wpdb->insert(
                                $suspicious_table_name,
                                array(
                                    'file' => $file->getPathname(),
                                    'line' => $line_number + 1, // Line numbers start from 1
                                    'pattern' => $pattern,
                                    'full_code' => trim($line_content), // Store the full line code here
                                    'risk_level' => $risk_level, // Set the risk level
                                    'modified' => gmdate('Y-m-d H:i:s', filemtime($file->getPathname())), // Record the modification time
                                    'detected' => current_time('mysql', 1) // Record the detection time in GMT
                                )
                            );
                            $found_entries[] = $wpdb->insert_id;
                        } else {
                            // Update the existing entry with the latest modification and detection time
                            $wpdb->update(
                                $suspicious_table_name,
                                array(
                                    'modified' => gmdate('Y-m-d H:i:s', filemtime($file->getPathname())),
                                    'detected' => current_time('mysql', 1),
                                    'full_code' => trim($line_content) // Update the full code if necessary
                                ),
                                array('id' => $existing_entry)
                            );
                            $found_entries[] = $existing_entry;

                            // Generate image for this suspicious code
                            $image_path = generate_suspicious_image(trim($line_content), $file->getPathname(), $line_number + 1);
                        }
                        break; // No need to continue checking patterns for this line
                    }
                }
            }
        }
    }

    // Remove entries from the database that were not found in the latest scan
    if (!empty($found_entries)) {
        $found_entries_list = implode(',', array_map('intval', $found_entries));
        $wpdb->query("DELETE FROM $suspicious_table_name WHERE id NOT IN ($found_entries_list)");
    }
}

// Hook the scanning function to the daily event
add_action('directory_scan_daily_event', 'directory_scan_files');

// Function to display suspicious files in the admin panel
function display_suspicious_files() {
    // Check if 'realTimeNeutra' is set to 'yes'
    $real_time_Neutra = get_option('realTimeNeutra');
    if ($real_time_Neutra === 'yes') {
        //echo '<p>Suspicious file display is disabled because real-time neutralization is enabled.</p>';
        return; // Exit the function if real-time neutralization is enabled
    }

    global $wpdb;
    $suspicious_table_name = $wpdb->prefix . 'suspicious_files';

    // Get the stored scan results, ordered by last modified time descending
    $suspicious_files_list = $wpdb->get_results("SELECT * FROM $suspicious_table_name ORDER BY modified DESC");

    // Check if there are any suspicious files
    if (!empty($suspicious_files_list)) {
        echo '<h2>Suspicious Files</h2>';
        echo '<table class="widefat">';
        echo '<thead><tr><th>File</th><th>Line</th><th>Risk Level</th><th>Last Modified</th><th>Detection Time</th><th>Actions</th></tr></thead>';
        echo '<tbody>';
        foreach ($suspicious_files_list as $file) {
            $modified_time = strtotime($file->modified);
            $time_diff_modified = human_time_diff($modified_time, current_time('timestamp'));
            echo '<tr>';
            echo '<td>' . esc_html($file->file) . '</td>';
            echo '<td>' . esc_html($file->line) . '</td>';

            // Set color based on risk level
            $color = '';
            switch ($file->risk_level) {
                case 'None':
                    $color = 'blue';
                    break;
                case 'High':
                    $color = 'red';
                    break;
                case 'Medium':
                    $color = 'orange';
                    break;
                case 'Low':
                    $color = 'green';
                    break;
                default:
                    $color = 'black'; // Default color
            }
            echo '<td style="color: ' . $color . ';">' . esc_html($file->risk_level) . '</td>';
            echo '<td>' . esc_html($time_diff_modified) . ' ago</td>';
            echo '<td>' . esc_html(get_date_from_gmt($file->detected)) . '</td>';
            echo '<td>';
            // Add the Neutralize button
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
            echo '<input type="hidden" name="action" value="neutralize_file">';
            echo '<input type="hidden" name="file_id" value="' . esc_attr($file->id) . '">';
            echo '<input type="submit" class="button button-primary" name="neutralize_file" value="Neutralize">';
            echo '</form>';
            echo '</td>';
            echo '</tr>';
        }
        echo '</tbody>';
        echo '</table>';
    } else {
        echo '<p>No suspicious files found.</p>';
    }
}


// Add admin menu page
function directory_scanner_page() {
    $real_time_neutra = get_option('realTimeNeutra');
    ?>
    <div class="wrap">
    <?php if ($real_time_neutra !== 'yes') : ?>
    <h1>Scan Malware Intrusion</h1>
    <p>Click the button below to manually scan your WordPress directory to find malware.</p>
    <form method="post" action="">
    <?php wp_nonce_field('directory_scanner_nonce', 'directory_scanner_nonce_field'); ?>
    <input type="submit" class="button button-primary" name="scan_directory_files" value="Scan">
    </form>
    <?php else : ?>
    <h1><span style="color: RED; font-style: bold;">Real-Time Malware Neutralization is ACTIVE</span></h1>
    <p><b>All incoming malware threats will be neutralized automatically. To see the report, check your admin email or visit the Neutralized Files section or <a href="<?php echo esc_url(admin_url('admin.php?page=neutralized-files')); ?>">CLICK HERE</a></p>

    <p>Thank you,</p>
    <p><strong>BITSS TEAM</strong></p>
    <?php endif; ?>
    <?php
    if (isset($_POST['scan_directory_files']) && wp_verify_nonce($_POST['directory_scanner_nonce_field'], 'directory_scanner_nonce')) {
    directory_scan_files();
    display_suspicious_files();
    } else {
    display_suspicious_files();
    }
    ?>
    </div>
    <?php
    }