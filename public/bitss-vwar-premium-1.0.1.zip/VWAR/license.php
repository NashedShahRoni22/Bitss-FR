<?php

add_action('admin_menu', function() {
	add_menu_page(
		'BITSS frontline virus war defender', //page title
		'VWAR', //menu title
		'manage_options', //capability 
		'bitss-protection', //menu slug
		'vwar_license_page', //callback function
		'dashicons-shield', //icon_url
		10 //position
	);
});

if ($vwar_license && isset($vwar_license['valid_till'])) {
	// Create DateTime objects for comparison
	$vwar_valid_till_date = new DateTime($vwar_license['valid_till']);
	$vwar_current_date = new DateTime();

	// Compare the current date with the valid_till date
	if ($vwar_current_date > $vwar_valid_till_date) {
		// Show warning if the current date is newer than the valid_till date
		function vwar_license_page() { ?>
			<div class="wrap">
    <div class="notice notice-error notice-alt">
	<b><p>Warning: <p>Your license has expired</b>, putting your site at risk and potentially exposing it to malware attacks.
        <br>Please <a href="https://bitss.fr/payment" style="color: #d9534f; font-weight: bold;">renew your license</a>
        <br> Mail to us <a href="mailto:support@bobosohomail.com">support@bobosohomail.com</a> for more assistance.</p>
    </div>
    <form method="post" action="options.php">
        <?php
        settings_fields('vwar-settings-group');
        do_settings_sections('vwar-settings-group');
        ?>
        <table class="form-table">
            <tr valign="top">
                <th scope="row">Username</th>
                <td>
                    <input type="text" name="vwar_username" value="<?php echo esc_attr(get_option('vwar_username')); ?>" />
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">License Key</th>
                <td>
                    <input type="text" name="vwar_key" value="<?php echo esc_attr(get_option('vwar_key')); ?>" />
                </td>
            </tr>
            <tr valign="top">
            </tr>     
        </table>
        <?php submit_button('Revalidate License'); ?>
    </form>
</div>

		<?php }
	} else {
		require_once 'alltime_modify.php';
		require_once 'directory_scanner.php';
		require_once 'neutralize.php';
		require_once 'settings.php';
		// Execute some function if the license is still valid
		function vwar_license_page() {
			global $vwar_license;
			?>
			<div class="wrap">
				
				<div class="notice notice-success notice-alt">
					<h3>License Activated<h3>
						<h4>License Validity: <?php echo $vwar_license['valid_till']; ?> 
					<br>Thanks for Choosing BITSS VWAR
					<br>For more details visit <a href="https://bitss.fr" style="color:rgb(255, 7, 7); font-weight: bold;">BITSS.FR</a>
					<br> Mail to us <a href="mailto:support@bobosohomail.com">support@bobosohomail.com</a> for more assistance.</p>
				</h4>
				</div>
				
			</div>
			<?php
		}
		add_action('admin_menu', function() {
			add_menu_page(
				'manage_options', //capability 
				'bitss-protection', //menu slug
				'vwar_license_page', //callback function
				'dashicons-shield', //icon_url
				10 //position
			);
			add_submenu_page(
				'bitss-protection',
				'VWAR License',
				'License', //menu title
				'manage_options', //capability 
				'bitss-protection', //menu slug
				'vwar_license_page', //callback function
			);
			
			add_submenu_page(
				'bitss-protection', // Parent menu slug
				'VWAR Settings', // Page title
				'Settings', // Menu title
				'manage_options', // Capability required
				'settings', // Menu slug
				'scanner_settings_page_html' // Callback function
			);
		   
			add_submenu_page(
				'bitss-protection', // Parent menu slug
				'Malware Coding Intrusion', // Page title
				'Malware Coding Intrusion', // Menu title
				'manage_options', // Capability required
				'directory-scanner', // Menu slug
				'directory_scanner_page' // Callback function
			);
			
			add_submenu_page(
				'bitss-protection', // Parent menu slug
				'Neutralized Files', // Page title
				'Neutralized Files', // Menu title
				'manage_options', // Capability required
				'neutralized-files', // Menu slug
				'display_neutralized_files' // Callback function
			);
			
			add_submenu_page(
				'bitss-protection', // Parent menu slug
				'Modified Files', // Page title
				'Modified Files', // Menu title
				'manage_options', // Capability required
				'modified-files', // Menu slug
				'display_all_modified_files' // Callback function
			);
		});
	}
} else {
	function vwar_license_page() { 
		if(empty(get_option('vwar_username')) && empty(get_option('vwar_password'))) {
			?>
			<div class="wrap">
				<div class="notice notice-primary notice-alt"><p>Please enter the license key to activate BITSS Virus War Frontline Defender. Need Support? Please visit <a href="https://bitss.fr">BITSS.FR</a>. Thank you.</p></div>
				
				<form method="post" action="options.php">
					<?php
					settings_fields('vwar-settings-group');
					do_settings_sections('vwar-settings-group');
					?>
					<table class="form-table">
						<tr valign="top">
							<th scope="row">Username</th>
							<td>
								<input type="text" name="vwar_username" value="<?php echo esc_attr(get_option('vwar_username')); ?>" />
							</td>
						</tr>
						<tr valign="top">
							<th scope="row">License Key</th>
							<td>
								<input type="text" name="vwar_key" value="<?php echo esc_attr(get_option('vwar_key')); ?>" />
							</td>
						</tr>       
					</table>
					<?php submit_button(); ?>
				</form>
			</div>
			<?php
		} else {
			?>
			<div class="wrap">
				<div class="notice notice-error notice-alt"><p>The license data you have entered is expired or invalid. Kindly verify your license to maintain uninterrupted service. For further details, please visit <a href="https://bitss.fr">BITSS.FR</a>. Thank you.</p></div>
				
				<form method="post" action="options.php">
					<?php
					settings_fields('vwar-settings-group');
					do_settings_sections('vwar-settings-group');
					?>
					<table class="form-table">
						<tr valign="top">
							<th scope="row">Username</th>
							<td>
								<input type="text" name="vwar_username" value="<?php echo esc_attr(get_option('vwar_username')); ?>" />
							</td>
						</tr>
						<tr valign="top">
							<th scope="row">License Key</th>
							<td>
								<input type="text" name="vwar_key" value="<?php echo esc_attr(get_option('vwar_key')); ?>" />
							</td>
						</tr>       
					</table>
					<?php submit_button(); ?>
				</form>
			</div>
			<?php
		}
	}
}

add_action('admin_init', function() {
    register_setting('vwar-settings-group', 'vwar_username');
    register_setting('vwar-settings-group', 'vwar_key');
});