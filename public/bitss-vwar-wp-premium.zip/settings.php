<?php
// HTML for the settings page
function scanner_settings_page_html() {
    if (!current_user_can('manage_options')) {
    return;
    }
    
    if (isset($_POST['scanner_interval'])) {
    update_option('scanner_interval', sanitize_text_field($_POST['scanner_interval']));
    // Reschedule cron job with the new interval
    scanner_reschedule_cron();
    }
    
    $interval = get_option('scanner_interval', 'hourly');
    ?>
    <div class="wrap">
    <h1>Auto-Detection Settings</h1>
    <p>Customize the interval to suit your preferences, with four default options available. Choose from the menu and click "Save Changes" to apply.</p>
    <form method="post" action="">
    <label for="scanner_interval">Scan Interval</label>
    <select id="scanner_interval" name="scanner_interval">
    <option value="hourly" <?php selected($interval, 'hourly'); ?>>Hourly</option>
    <option value="twicedaily" <?php selected($interval, 'twicedaily'); ?>>Twice Daily</option>
    <option value="daily" <?php selected($interval, 'daily'); ?>>Once Daily</option>
    <option value="every30seconds" <?php selected($interval, 'every30seconds'); ?>>Realtime</option>
    </select>
    <?php submit_button('Save Changes'); ?>
    </form>
    </div>
    
    <div class="wrap">
    <h1>Real-Time Malware Neutralization</h1>
    <p>To enable automatic malware code removal when detected, select either "Yes" or "No" from the menu, then click "Save Changes."</p>
    <form method="post" action="">
    <label for="realTimeNeutra">Choose Options</label>
    <select id="realTimeNeutra" name="realTimeNeutra">
    <option value="yes" <?php selected(get_option('realTimeNeutra'), 'yes'); ?>>Yes</option>
    <option value="no" <?php selected(get_option('realTimeNeutra'), 'no'); ?>>No</option>
    </select>
    <!-- Selected Value: <?php echo get_option('realTimeNeutra'); ?> -->
    <br><br>
    <?php wp_nonce_field('save_realTimeNeutra', 'realTimeNeutra_nonce'); ?>
    <button type="submit" name="submit_realTimeNeutra" class="button button-primary">Save Changes</button>
    </form>
    </div>

    
    <?php
    }
    
    // Add custom intervals to the cron schedule
    add_filter('cron_schedules', 'scanner_custom_intervals');
    function scanner_custom_intervals($schedules) {
    $schedules['hourly'] = array(
    'interval' => 3600,
    'display'  => __('Every Hour')
    );
    $schedules['twicedaily'] = array(
    'interval' => 43200,
    'display'  => __('Twice Daily')
    );
    $schedules['daily'] = array(
    'interval' => 86400,
    'display'  => __('Once Daily')
    );
    // Add new interval
    $schedules['every30seconds'] = array(
    'interval' => 30,
    'display'  => __('Realtime')
    );
    return $schedules;
    }
    
    // Schedule the event based on the selected interval
    function scanner_reschedule_cron() {
    $timestamp = wp_next_scheduled('scanner_cron_hook');
    if ($timestamp) {
    wp_unschedule_event($timestamp, 'scanner_cron_hook');
    }
    $interval = get_option('scanner_interval', 'hourly');
    wp_schedule_event(time(), $interval, 'scanner_cron_hook');
    }
    
    // Hook to run the scan function
    add_action('scanner_cron_hook', 'directory_scan_files');
    
    // On plugin activation, schedule the cron job
    register_activation_hook(__FILE__, 'scanner_reschedule_cron');
    
    // On plugin deactivation, clear the cron job
    register_deactivation_hook(__FILE__, 'scanner_clear_cron');
    function scanner_clear_cron() {
    $timestamp = wp_next_scheduled('scanner_cron_hook');
    if ($timestamp) {
    wp_unschedule_event($timestamp, 'scanner_cron_hook');
    }
    }
    
    add_action('init', 'handle_realTimeNeutra_submission');

//Realtime Neutralization System
function handle_realTimeNeutra_submission() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_realTimeNeutra'])) {
        // Ensure the WordPress function is available
        if (!function_exists('check_admin_referer')) {
            die('WordPress is not loaded properly.');
        }

        // Verify the nonce for security
        if (!check_admin_referer('save_realTimeNeutra', 'realTimeNeutra_nonce')) {
            die('Security check failed.');
        }

        // Sanitize and save the option
        $realTimeNeutra_value = sanitize_text_field($_POST['realTimeNeutra']);
        update_option('realTimeNeutra', $realTimeNeutra_value);
        
        // Display a success message
        echo '<div class="notice notice-success"><p>Option saved successfully!</p></div>';
    }
}
