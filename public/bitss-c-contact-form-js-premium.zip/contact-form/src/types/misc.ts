export interface IContact {
  name: string;
  email: string;
  phone: string;
  country: string;
  subject: string;
  message: string;
}

export interface ICountry {
  name: string;
  dialling_code: string;
}
