<?php
if ($license && isset($license['valid_till'])) {
	$valid_till_date = new DateTime($license['valid_till']);
	$current_date = new DateTime();

	if ($current_date > $valid_till_date) {
		require_once __DIR__ . '/page/settings.php';
		add_action('admin_menu', function() {
			add_menu_page('Bitss Wap Settings', 'Bitss Wap', 'manage_options', 'bitss-settings', 'bitss_settings', 'dashicons-privacy', 10);
			add_submenu_page('bitss-settings', 'Bitss Wap Settings', 'Settings', 'manage_options', 'bitss-settings', 'bitss_settings');
		});
	} else {
		require_once __DIR__ . '/page/settings.php';
		require_once __DIR__ . '/page/admin-ip.php';
		require_once __DIR__ . '/page/blacklist-ip.php';
		require_once __DIR__ . '/page/whitelist-ip.php';
		require_once __DIR__ . '/page/login-user.php';
		add_action('admin_menu', function() {
			add_menu_page('Bitss Wap Settings', 'Bitss Wap', 'manage_options', 'bitss-settings', 'bitss_settings', 'dashicons-privacy', 10);
			add_submenu_page('bitss-settings', 'Bitss Wap Settings', 'Settings', 'manage_options', 'bitss-settings', 'bitss_settings');
			add_submenu_page('bitss-settings', 'Blacklist IP', 'Blacklist IP', 'manage_options', 'blacklist-ip', 'blacklist_manage_settings');
			add_submenu_page('bitss-settings', 'Whitelist IP', 'Whitelist IP', 'manage_options', 'whitelist-ip', 'whitelist_manage_settings');
			add_submenu_page('bitss-settings', 'Admin Login IP', 'Admin Login IP', 'manage_options', 'login-access', 'login_access_settings');
			add_submenu_page('bitss-settings', 'Logged In Users', 'Logged In Users', 'manage_options', 'login-users', 'login_users_settings');
		});
	}
} else {
	require_once __DIR__ . '/page/settings.php';
	add_action('admin_menu', function() {
		add_menu_page('Bitss Wap Settings', 'Bitss Wap', 'manage_options', 'bitss-settings', 'bitss_settings', 'dashicons-privacy', 10);
		add_submenu_page('bitss-settings', 'Bitss Wap Settings', 'Settings', 'manage_options', 'bitss-settings', 'bitss_settings');
	});
}