<div class="customwrap">
	<div class="preselectFormAdminSettings">
		<h2>Bitss Preselect Contact Form Settings</h2>
		<p>Please uncheck the fields, which you want to hide from contact form.</p>
		<form method="post" action="options.php">
			<?php
				settings_fields('preselect_plugin_options_group');
				do_settings_sections('preselect_plugin_options_group');
			?>
						
			<table class="form-table">	
				<tr>
					<th><label for="first_field_id">Name:</label></th>
					<td>
						Show?
						<input class="form-check-input" name="nameField" type="checkbox" value="1" id="nameField" <?php checked(get_option('nameField'), 1); ?>>
						<?php
							if(get_option('nameField') == 1) {
						?>
						Required?
						<input class="form-check-input" name="nameFieldRequired" type="checkbox" value="1" id="nameFieldRequired" <?php checked(get_option('nameFieldRequired'), 1); ?>>
						<?php } ?>
					</td>
				</tr>
	
				<tr>
					<th><label for="first_field_id">Email:</label></th>
					<td>
						Show?
						<input class="form-check-input" name="emailField" type="checkbox" value="1" id="emailField" <?php checked(get_option('emailField'), 1); ?>>
						<?php
							if(get_option('emailField') == 1) {
						?>
						Required?
						<input class="form-check-input" name="emailFieldRequired" type="checkbox" value="1" id="emailFieldRequired" <?php checked(get_option('emailFieldRequired'), 1); ?>>
						<?php } ?>
					</td>
				</tr>
				
				<tr>
					<th><label for="first_field_id">Phone:</label></th>
					<td>
						Show?
						<input class="form-check-input" name="phoneField" type="checkbox" value="1" id="phoneField" <?php checked(get_option('phoneField'), 1); ?>>
						<?php
							if(get_option('phoneField') == 1) {
						?>
						Required?
						<input class="form-check-input" name="phoneFieldRequired" type="checkbox" value="1" id="phoneFieldRequired" <?php checked(get_option('phoneFieldRequired'), 1); ?>>
						<?php } ?>
					</td>
				</tr>
				
				<tr>
					<th><label for="first_field_id">Country:</label></th>
					<td>
						Show?
						<input class="form-check-input" name="countryField" type="checkbox" value="1" id="countryField" <?php checked(get_option('countryField'), 1); ?>>
						<?php
							if(get_option('countryField') == 1) {
						?>
						Required?
						<input class="form-check-input" name="countryFieldRequired" type="checkbox" value="1" id="countryFieldRequired" <?php checked(get_option('countryFieldRequired'), 1); ?>>
						<?php } ?>
					</td>
				</tr>
				
				<tr>
					<th><label for="first_field_id">Company Name:</label></th>
					<td>
						Show?
						<input class="form-check-input" name="companyField" type="checkbox" value="1" id="companyField" <?php checked(get_option('companyField'), 1); ?>>
						<?php
							if(get_option('companyField') == 1) {
						?>
						Required?
						<input class="form-check-input" name="companyFieldRequired" type="checkbox" value="1" id="companyFieldRequired" <?php checked(get_option('companyFieldRequired'), 1); ?>>
						<?php } ?>
					</td>
				</tr>
				
				<tr>
					<th><label for="first_field_id">How do your hear about us:</label></th>
					<td>
						Show?
						<input class="form-check-input" name="hearField" type="checkbox" value="1" id="hearField" <?php checked(get_option('hearField'), 1); ?>>
						<?php
							if(get_option('hearField') == 1) {
						?>
						Required?
						<input class="form-check-input" name="hearFieldRequired" type="checkbox" value="1" id="hearFieldRequired" <?php checked(get_option('hearFieldRequired'), 1); ?>>
						<?php } ?>
					</td>
				</tr>
				
				<tr>
					<th><label for="first_field_id">Contact me through:</label></th>
					<td>
						Show?
						<input class="form-check-input" name="connectField" type="checkbox" value="1" id="connectField" <?php checked(get_option('connectField'), 1); ?>>
						<?php
							if(get_option('connectField') == 1) {
						?>
						Required?
						<input class="form-check-input" name="connectFieldRequired" type="checkbox" value="1" id="connectFieldRequired" <?php checked(get_option('connectFieldRequired'), 1); ?>>
						<?php } ?>
					</td>
				</tr>
				
				<tr>
					<th><label for="first_field_id">Skype:</label></th>
					<td>
						Show?
						<input class="form-check-input" name="skypeField" type="checkbox" value="1" id="skypeField" <?php checked(get_option('skypeField'), 1); ?>>
						<?php
							if(get_option('skypeField') == 1) {
						?>
						Required?
						<input class="form-check-input" name="skypeFieldRequired" type="checkbox" value="1" id="skypeFieldRequired" <?php checked(get_option('skypeFieldRequired'), 1); ?>>
						<?php } ?>
					</td>
				</tr>
				
				<tr>
					<th><label for="first_field_id">Whatsapp:</label></th>
					<td>
						Show?
						<input class="form-check-input" name="whatsappField" type="checkbox" value="1" id="whatsappField" <?php checked(get_option('whatsappField'), 1); ?>>
						<?php
							if(get_option('whatsappField') == 1) {
						?>
						Required?
						<input class="form-check-input" name="whatsappFieldRequired" type="checkbox" value="1" id="whatsappFieldRequired" <?php checked(get_option('whatsappFieldRequired'), 1); ?>>
						<?php } ?>
					</td>
				</tr>
				
				<tr>
					<th><label for="first_field_id">Facebook:</label></th>
					<td>
						Show?
						<input class="form-check-input" name="facebookField" type="checkbox" value="1" id="facebookField" <?php checked(get_option('facebookField'), 1); ?>>
						<?php
							if(get_option('facebookField') == 1) {
						?>
						Required?
						<input class="form-check-input" name="facebookFieldRequired" type="checkbox" value="1" id="facebookFieldRequired" <?php checked(get_option('facebookFieldRequired'), 1); ?>>
						<?php } ?>
					</td>
				</tr>
				
				<tr>
					<th><label for="first_field_id">Subject:</label></th>
					<td>
						Show?
						<input class="form-check-input" name="subjectField" type="checkbox" value="1" id="subjectField" <?php checked(get_option('subjectField'), 1); ?>>
						<?php
							if(get_option('subjectField') == 1) {
						?>
						Required?
						<input class="form-check-input" name="subjectFieldRequired" type="checkbox" value="1" id="subjectFieldRequired" <?php checked(get_option('subjectFieldRequired'), 1); ?>>
						<?php } ?>
					</td>
				</tr>
				
				<tr>
					<th><label for="first_field_id">Message:</label></th>
					<td>
						Show?
						<input class="form-check-input" name="messageField" type="checkbox" value="1" id="messageField" <?php checked(get_option('messageField'), 1); ?>>
						<?php
							if(get_option('messageField') == 1) {
						?>
						Required?
						<input class="form-check-input" name="messageFieldRequired" type="checkbox" value="1" id="messageFieldRequired" <?php checked(get_option('messageFieldRequired'), 1); ?>>
						<?php } ?>
					</td>
				</tr>
				
				<tr>
					<th><label for="first_field_id">Mailing address:</label></th>
					<td>
						Show?
						<input class="form-check-input" name="mailingField" type="checkbox" value="1" id="mailingField" <?php checked(get_option('mailingField'), 1); ?>>
						<?php
							if(get_option('mailingField') == 1) {
						?>
						Required?
						<input class="form-check-input" name="mailingFieldRequired" type="checkbox" value="1" id="mailingFieldRequired" <?php checked(get_option('mailingFieldRequired'), 1); ?>>
						<?php } ?>
					</td>
				</tr>

			</table>
		<?php
			submit_button('Save Settings');
		?>
		</form>
	</div>
	<div class="preselectFormAdminSettings adminViewBG">
		<h1 class="mb3">Form view will update after save the settings</h1>
		<?php
			if(get_option('nameField') == 1) {
		?>
		<div class="mb3">
			<label for="name" class="input-label">Name
				<?php if(get_option('nameFieldRequired') == 1){ echo '*'; }?></label>
			<input type="text" class="input-class" id="name">
		</div>
		<?php } ?>

		<?php
			if(get_option('emailField') == 1) {
		?>
		<div class="mb3">
			<label for="email" class="input-label">Email <?php if(get_option('emailFieldRequired') == 1){ echo '*'; }?></label>
			<input type="text" class="input-class" id="email">
		</div>
		<?php } ?>

		<?php
			if(get_option('phoneField') == 1) {
		?>
		<div class="mb3">
			<label for="phone" class="input-label">Phone
				<?php if(get_option('phoneFieldRequired') == 1){ echo '*'; }?></label>
			<div class="custom-select-group mb3">
				<div class="custom-select">
					<select id="phonecode" name="phonecode" class="" required>
						<option value="">Select Country Code</option>
					</select>
				</div>
				<input type="text" class="input-class" id="phone">
			</div>
		</div>
		<?php } ?>

		<?php
			if(get_option('countryField') == 1) {
		?>
		<div class="mb3">
			<label for="country" class="input-label">Country <?php if(get_option('countryFieldRequired') == 1){ echo '*'; }?></label>
			<div class="custom-select">
				<select id="country" name="country" class="">
					<option value="">Select Country</option>
				</select>
			</div>
		</div>
		<?php } ?>

		<?php
			if(get_option('companyField') == 1) {
		?>
		<div class="mb3">
			<label for="company" class="input-label">Company Name <?php if(get_option('companyFieldRequired') == 1){ echo '*'; }?></label>
			<input type="text" class="input-class" id="company">
		</div>
		<?php } ?>

		<?php
			if(get_option('hearField') == 1) {
		?>
		<div class="mb3">
			<label for="hear" class="input-label">How do you hear about us? <?php if(get_option('hearFieldRequired') == 1){ echo '*'; }?></label>
			<div class="custom-select">
				<select id="hear" name="hear" class="">
					<option value="" selected>Please select option</option>
				</select>
			</div>
		</div>
		<?php } ?>

		<?php
			if(get_option('connectField') == 1) {
		?>
		<div class="mb3">
			<label for="connect" class="input-label">Contact me through? <?php if(get_option('connectFieldRequired') == 1){ echo '*'; }?></label>
			<div class="custom-select">
				<select id="connect" name="connect" class="">
					<option value="" selected>Please select option</option>
				</select>
			</div>
		</div>
		<?php } ?>

		<?php
			if(get_option('skypeField') == 1) {
		?>
		<div class="mb3">
			<label for="skype" class="input-label">Skype (For Contact Purpose)
				<?php if(get_option('skypeFieldRequired') == 1){ echo '*'; }?></label>
			<input type="text" class="input-class" id="skype">
		</div>
		<?php } ?>

		<?php
			if(get_option('facebookField') == 1) {
		?>
		<div class="mb3">
			<label for="facebook" class="form-label">Facebook (For Contact Purpose) <?php if(get_option('facebookFieldRequired') == 1){ echo '*'; }?></label>
			<input type="text" class="input-class" id="facebook">
		</div>
		<?php } ?>

		<?php
			if(get_option('whatsappField') == 1) {
		?>
		<div class="mb3">
			<label for="whatsapp" class="input-label">Whatsapp (For Contact Purpose) <?php if(get_option('whatsappFieldRequired') == 1){ echo '*'; }?></label>
			<input type="text" class="input-class" id="whatsapp">
			<div id="whatsappHelp" class="form-text text-black-50">Please input whatsapp number with country code without + sign.</div>
		</div>
		<?php } ?>


		<?php
			if(get_option('subjectField') == 1) {
		?>
		<div class="mb3">
			<label for="subject" class="input-label">Subject/Query for <?php if(get_option('subjectFieldRequired') == 1){ echo '*'; }?></label>
			<input type="text" name="subject" id="subject" class="input-class">
		</div>
		<?php } ?>

		<?php
			if(get_option('messageField') == 1) {
		?>
		<div class="mb3">
			<label for="message" class="input-label">Message <?php if(get_option('messageFieldRequired') == 1){ echo '*'; }?></label>
			<textarea name="message" id="message" rows="10" class="form-label"></textarea>
		</div>
		<?php } ?>

		<?php
			if(get_option('mailingField') == 1) {
		?>
		<div class="mb3">
			<label for="mailing" class="input-label">Mailing Address <?php if(get_option('mailingFieldRequired') == 1){ echo '*'; }?></label>
			<textarea name="mailing" id="mailing" rows="10" class="form-label"></textarea>
		</div>
		<?php } ?>
	</div>
</div>