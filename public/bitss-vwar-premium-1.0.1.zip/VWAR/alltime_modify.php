<?php 
// Function to display all modified files in the admin panel
function display_all_modified_files() {
    // Get a list of all files in the "root" directory
    $root_files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator(ABSPATH, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );

    // Define the list of files or directories to ignore
    $ignore_list = ['cache'];

    // Initialize arrays to store files categorized by modification time
    $latest_files = [];
    $last_7_days_files = [];
    $last_15_days_files = [];

    // Check if there are any files in the "root" directory
    if (!empty($root_files)) {
        foreach ($root_files as $file) {
            $file_path = $file->getPathname();
            
            // Check if the file or directory should be ignored (This function is for ignoring cache folder)
            $should_ignore = false;
            foreach ($ignore_list as $ignore_item) {
                if (stripos($file_path, $ignore_item) !== false) {
                    $should_ignore = true;
                    break;
                }
            }

            if ($should_ignore) {
                continue;
            }

            // Check if it's a file
            if ($file->isFile()) {
                // Get the last modified time of the file
                $modified_time = $file->getMTime();
                
                // Determine the time difference in seconds
                $time_diff_seconds = time() - $modified_time;

                // Format the modification time as human-readable
                $formatted_time = human_time_diff($modified_time, current_time('timestamp')) . ' ago';

                // Categorize files based on modification time
                if ($time_diff_seconds <= 86400) { // Last 24 hours
                    $latest_files[] = [
                        'path' => $file_path,
                        'modified' => $formatted_time
                    ];
                } elseif ($time_diff_seconds <= 604800) { // Last 7 days
                    $last_7_days_files[] = [
                        'path' => $file_path,
                        'modified' => $formatted_time
                    ];
                } elseif ($time_diff_seconds <= 1296000) { // Last 15 days
                    $last_15_days_files[] = [
                        'path' => $file_path,
                        'modified' => $formatted_time
                    ];
                }
            }
        }
        
        // Display categorized files using tabs
        echo '<div class="wrap">';
        echo '<h2>Modified Files</h2><br>';

        // Latest files tab buttons
        echo '<button class="button button-primary" onclick="openTab(event, \'latest\')" id="defaultOpen">Last 24 Hours</button>';
        echo '&nbsp;';
        echo '<button class="button button-primary" onclick="openTab(event, \'last7days\')">Last 7 Days</button>';
        echo '&nbsp;';
        echo '<button class="button button-primary" onclick="openTab(event, \'last15days\')">Last 15 Days</button>';
        echo '&nbsp;';

        // Latest files tab content
        echo '<div id="latest" class="tabcontent">';
        display_files_in_table($latest_files);
        echo '</div>';

        // Last 7 days files tab content
        echo '<div id="last7days" class="tabcontent">';
        display_files_in_table($last_7_days_files);
        echo '</div>';

        // Last 15 days files tab content
        echo '<div id="last15days" class="tabcontent">';
        display_files_in_table($last_15_days_files);
        echo '</div>';
        echo '</div>'; // Close .wrap

        // JavaScript to handle tab functionality and activate the default tab
        echo '<script>
        document.getElementById("defaultOpen").click();
        function openTab(evt, tabName) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }
            tablinks = document.getElementsByClassName("tablink");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
            }
            document.getElementById(tabName).style.display = "block";
            evt.currentTarget.className += " active";
        }
        </script>';
    } else {
        echo '<div class="wrap">';
        echo '<h2>All Modified Files</h2>';
        echo '<p>No files found.</p>';
        echo '</div>';
    }
}

// Helper function to display files in a table
function display_files_in_table($files) {
    if (!empty($files)) {
        echo '&nbsp;';
        echo '<table class="widefat">';
        echo '<thead><tr><th>File</th><th>Last Modified</th></tr></thead>';
        echo '<tbody>';
        foreach ($files as $file) {
            echo '<tr><td>' . esc_html($file['path']) . '</td><td>' . esc_html($file['modified']) . '</td></tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p>No files found.</p>';
    }
}