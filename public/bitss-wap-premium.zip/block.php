<?php
/**
 * BITSS WAP for WordPress
 * Powered by BFINIT Ltd.
 * Author: BITSS Team
 * Maintain by: M Rahman Sayed
 * URL: https://github.com/mrahmansayed
 */

// Failed login ip store to the database
add_action('wp_login_failed', function() {
    global $wpdb;
	
	if (isset($_GET['loggedout'])) {
        return; // Skip if the query parameter 'loggedout' is present
    }
	
    // Get client ip
    $user_ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
    $admin_table = $wpdb->prefix . 'ip_admin';
    $blacklist_table = $wpdb->prefix . 'ip_blacklist';
    $whitelist_table = $wpdb->prefix . 'ip_whitelist';

    $is_admin = $wpdb->get_row($wpdb->prepare("SELECT * FROM $admin_table WHERE ip_address = %s", $user_ip));
    if ($is_admin) {
        $wpdb->update(
            $admin_table,
            array('failed_login_count' => $is_admin->failed_login_count + 1),
            array('id' => $is_admin->id),
            array('%d'),
            array('%d')
        );
    }

    $is_whitelisted = $wpdb->get_var($wpdb->prepare("SELECT * FROM $whitelist_table WHERE ip_address = %s", $user_ip));
    if ($is_whitelisted) {
        return;
    }

    $blacklist_ip = $wpdb->get_row($wpdb->prepare("SELECT * FROM $blacklist_table WHERE ip_address = %s", $user_ip));
    if ($blacklist_ip) {
        $wpdb->update(
            $blacklist_table,
            array('ip_count' => $blacklist_ip->ip_count + 1),
            array('id' => $blacklist_ip->id),
            array('%d'),
            array('%d')
        );
    } else {
        $wpdb->insert(
            $blacklist_table,
            array(
                'ip_address' => $user_ip,
                'ip_name' => 'Unknown',
                'ip_count' => 1,
                'attempt_timestamp' => current_time('mysql')
            ),
            array('%s', '%s', '%d', '%s')
        );
    }
});

add_action('wp_loaded', function() {
    global $wpdb;
    $table_admin = $wpdb->prefix . 'ip_admin';
    $table_whitelist = $wpdb->prefix . 'ip_whitelist';
    $table_blacklist = $wpdb->prefix . 'ip_blacklist';
    /*if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		$user_ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
	} else {
		$user_ip = $_SERVER['REMOTE_ADDR'];
	}*/
	$user_ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
    $is_admin = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_admin WHERE ip_address = %s", $user_ip));
    if ($is_admin) {
       $ip_count_block = $wpdb->get_var(
           $wpdb->prepare("SELECT failed_login_count FROM $table_admin WHERE ip_address = %s", $user_ip)
       );
       if ($ip_count_block !== null && (int)$ip_count_block >= 3) {
           die(
           '<style>
               .access-denied {
                   font-family: Arial, sans-serif;
                   background-color: #eeeeee;
                   padding: 20px;
                   border-radius: 5px;
                   text-align: center;
                   box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                   max-width: 600px;
                   margin: 100px auto;
               }
               .access-denied h1 {
                   margin: 30px 0 0 0;
                   font-size: 24px;
               }
               .access-denied p {
                   margin: 10px 0 0;
                   font-size: 16px;
               }
               .access-denied p a {
                   margin: 30px 0 0;
                   font-size: 12px;
                   display: flex;
                   justify-content: center;
                   align-items: center;
               }
           </style>
           <div class="access-denied">
               <h1>Access Denied</h1>
               <p>You do not have the necessary permissions to view this page. Please contact the administrator if you believe this is an error.</p>
               <p><a href="https://bitss.fr">Performance and secured by BITSS <img src="https://bitss.fr/wp-content/uploads/2023/07/bitss_icon_1.png" width="50px"></a></p>
           </div>'
           );
       } else {
           return;
       }
    }

    $is_whitelisted = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_whitelist WHERE ip_address = %s", $user_ip));
    if ($is_whitelisted) {
        return;
    }

    // Retrieve the IP count directly
    $ip_count_block = $wpdb->get_var(
        $wpdb->prepare("SELECT ip_count FROM $table_blacklist WHERE ip_address = %s", $user_ip)
    );
    // Check if the count is 3 or more
    $ip_block_level_threshold = esc_attr(get_option('ip_block_level'));
    if ($ip_count_block !== null && (int)$ip_count_block >= $ip_block_level_threshold) {
        die(
        '<style>
            .access-denied {
                font-family: Arial, sans-serif;
                background-color: #eeeeee;
                padding: 20px;
                border-radius: 5px;
                text-align: center;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                max-width: 600px;
                margin: 100px auto;
            }
            .access-denied h1 {
                margin: 30px 0 0 0;
                font-size: 24px;
            }
            .access-denied p {
                margin: 10px 0 0;
                font-size: 16px;
            }
            .access-denied p a {
                margin: 30px 0 0;
                font-size: 12px;
                display: flex;
                justify-content: center;
                align-items: center;
            }
        </style>
        <div class="access-denied">
            <h1>Access Denied</h1>
            <p>You do not have the necessary permissions to view this page. Please contact the administrator if you believe this is an error.</p>
            <p><a href="https://bitss.fr/">Performance and secured by BITSS <img src="https://bitss.fr/wp-content/uploads/2023/07/bitss_icon_1.png" width="50px"></a></p>
        </div>'
        );
    }
});

// admin ip for access login page
add_action('wp_loaded', function() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ip_admin';
    $current_time = current_time('mysql'); // Get the current time in the same format as stored in the database
    // Fetch IP addresses and their validity
    $ips_query = $wpdb->get_results("SELECT ip_address, valid_till FROM $table_name");
    $allowed_ips = array();
    foreach ($ips_query as $ip) {
        if ($ip->valid_till > $current_time) { // Check if the valid_till is in the future
            $allowed_ips[] = $ip->ip_address;
        }
    }
	/*if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		$user_ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
	} else {
		$user_ip = $_SERVER['REMOTE_ADDR'];
	}*/
	$user_ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
    $login_page_requested = strpos($_SERVER['REQUEST_URI'], 'wp-login.php') !== false;
    $is_allowed_ip = in_array($user_ip, $allowed_ips);
    if (!$is_allowed_ip && $login_page_requested) {
        wp_redirect(home_url());
        exit;
    }
});

// ipsum threat settings
if (get_option('ipsum_threat') == 1) {
    add_action( 'wp_loaded', function() {
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }

        global $wpdb;
        $table_admin = $wpdb->prefix . 'ip_admin';
        $table_whitelist = $wpdb->prefix . 'ip_whitelist';

        $is_admin = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_admin WHERE ip_address = %s", $ip));
        if ($is_admin) {
            return;
        }

        $is_whitelisted = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_whitelist WHERE ip_address = %s", $ip));
        if ($is_whitelisted) {
            return;
        }

        $ipsum_response = wp_remote_get('https://raw.githubusercontent.com/stamparm/ipsum/master/ipsum.txt');
    
        if (is_wp_error($ipsum_response)) {
            // Print error for debugging
            error_log('Error: ' . $ipsum_response->get_error_message());
            return false;
        }
    
        $ipsum_content = wp_remote_retrieve_body($ipsum_response);
    
        if (empty($ipsum_content)) {
            // Print error for debugging
            error_log('Error: Empty response body.');
            return false;
        }
    
        $ipsum_ips = explode("\n", $ipsum_content);
        $blocked_ips = array_merge($ipsum_ips);
        if (in_array(trim($ip), $blocked_ips)) {
            die(
            '<style>
                .access-denied {
                    font-family: Arial, sans-serif;
                    background-color: #eeeeee;
                    padding: 20px;
                    border-radius: 5px;
                    text-align: center;
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                    max-width: 600px;
                    margin: 100px auto;
                }
                .access-denied h1 {
                    margin: 30px 0 0 0;
                    font-size: 24px;
                }
                .access-denied p {
                    margin: 10px 0 0;
                    font-size: 16px;
                }
                .access-denied p a {
                    margin: 30px 0 0;
                    font-size: 12px;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                }
            </style>
            <div class="access-denied">
                <h1>Access Denied</h1>
                <p>You do not have the necessary permissions to view this page. Please contact the administrator if you believe this is an error.</p>
                <p><a href="https://bitss.fr/">Performance and secured by BITSS <img src="https://bitss.fr/wp-content/uploads/2023/07/bitss_icon_1.png" width="50px"></a></p>
            </div>'
            );
        } else {
            return false;
        }
    });
}