<?php
/*
Plugin Name: VWAR (BITSS frontline virus war defender)
Plugin URI: https://bitss.fr
Description: Safeguard your WordPress site by blocking maximum malicious activities.
Version: 1.0.2
Author: BITSS Team by BFIN
Author URI: https://bitss.fr
License: GPLv2 or later
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

global $vwar_version;
global $vwar_license;

$vwar_version = '1.0.2';

$vwar_api = "https://bitts.fr/vwar/v1/api.php";
$vwar_username = get_option('vwar_username');
$vwar_password = get_option('vwar_key');
$vwar_domain = $_SERVER['SERVER_NAME'];

$vwar_curl = curl_init();
curl_setopt_array($vwar_curl, [
    CURLOPT_URL => $vwar_api,
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/x-www-form-urlencoded",
    ],
    CURLOPT_POSTFIELDS => http_build_query([
        'username' => $vwar_username,
        'password' => $vwar_password,
        'domain' => $vwar_domain,
    ]),
]);
$vwar_response = curl_exec($vwar_curl);
if (curl_errno($vwar_curl)) {
    error_log('cURL error: ' . curl_error($vwar_curl));
}
curl_close($vwar_curl);
$vwar_license = json_decode($vwar_response, true);


require_once 'license.php';
//require_once 'autoscan.php';

// Activation hook
register_activation_hook(__FILE__, 'bitss_activate');
function bitss_activate() {
    global $wpdb;
    $suspicious_table_name = $wpdb->prefix . 'suspicious_files';
    $neutralized_table_name = $wpdb->prefix . 'neutralized_files';

    // Create table (Suspicious Files)
    $charset_collate = $wpdb->get_charset_collate();
    $sql_suspicious = "CREATE TABLE $suspicious_table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        file varchar(255) NOT NULL,
        line int NOT NULL,
        pattern varchar(255) NOT NULL,
        full_code LONGTEXT NOT NULL,  -- Added column for full code
        risk_level varchar(20) NOT NULL,
        modified datetime NOT NULL,
        detected datetime NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY unique_file_line (file(191), line)
    ) $charset_collate";
    
    // Create table (Neutralized Files)
    $sql_neutralized = "CREATE TABLE $neutralized_table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        file varchar(255) NOT NULL,
        line int NOT NULL,
        pattern varchar(255) NOT NULL,
        full_code LONGTEXT NOT NULL,  -- Added column for full code
        risk_level varchar(20) NOT NULL,
        modified datetime NOT NULL,
        detected datetime NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY unique_file_line (file(191), line)
    ) $charset_collate";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql_suspicious);
    dbDelta($sql_neutralized);
    
    // Schedule daily scanning
    if (!wp_next_scheduled('directory_scan_daily_event')) {
        wp_schedule_event(time(), 'daily', 'directory_scan_daily_event');
    }
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'bitss_deactivate');
function bitss_deactivate() {
    // Remove scheduled scanning
    wp_clear_scheduled_hook('directory_scan_daily_event');
}

