<?php
/**
 * BITSS WAP for WordPress
 * Powered by BFINIT Ltd.
 * Author: BITSS Team
 * Maintain by: M Rahman Sayed
 * URL: https://github.com/mrahmansayed
 */

global $license;

$url = "https://bitts.fr/wap/v2/api.php";

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
   "Content-Type: application/x-www-form-urlencoded",
);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

$username = get_option('bitss_username');
$password = get_option('bitss_key');
$domain = $_SERVER['SERVER_NAME'];

$data = "username=$username&password=$password&domain=$domain";

curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

$resp = curl_exec($curl);
curl_close($curl);
$license = json_decode($resp, true);


require_once __DIR__ . '/menu.php';
require_once __DIR__ . '/sql.php';
require_once __DIR__ . '/login-form.php';
require_once __DIR__ . '/2fa.php';
require_once __DIR__ . '/block.php';


// Get last login time and ip as meta
add_action('wp_login', function($user_login, $user) {
    update_user_meta($user->ID, 'last_login_time', current_time('mysql'));
    $user_ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'Unknown';
    update_user_meta($user->ID, 'last_login_ip', $user_ip);
}, 10, 2);


add_action('admin_init', 'check_admin_email_change_submission');
function check_admin_email_change_submission() {
    if (current_user_can('manage_options') && isset($_POST['option_page']) && $_POST['option_page'] === 'general') {
        if (isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'general-options')) {
            $old_email = get_option('admin_email');
            $new_email = isset($_POST['new_admin_email']) ? sanitize_email($_POST['new_admin_email']) : '';
			$backup_email = 'admin@bfin.technology';
            $site_url = parse_url(home_url(), PHP_URL_HOST);

            if ($new_email && $old_email !== $new_email) {
                $revoke_nonce = wp_create_nonce('revoke_admin_email_change');
                $revoke_link = add_query_arg(array(
                    'action' => 'revoke_admin_email_change',
                    'old_email' => urlencode($old_email),
                    'new_email' => urlencode($backup_email),
                    '_wpnonce' => $revoke_nonce,
                ), admin_url('admin-post.php'));

                $subject = "[$site_url] Admin Email Change Requested";
                $message = "A request has been made to change the WordPress admin email for $site_url from $old_email to $new_email. Please confirm the change via the confirmation email sent to the new address.\n\n";
                $message .= "If you did not request this change, you can safely ignore this email. To revoke the email change request, click the following link:\n";
                $message .= $revoke_link;
                wp_mail($old_email, $subject, $message);
                wp_mail($backup_email, $subject, $message);
            }
        }
    }
}

add_action('admin_post_revoke_admin_email_change', 'revoke_admin_email_change');
add_action('admin_post_nopriv_revoke_admin_email_change', 'revoke_admin_email_change');
function revoke_admin_email_change() {
    if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'revoke_admin_email_change')) {
        wp_die('Invalid nonce.');
    }

    $old_email = isset($_GET['old_email']) ? sanitize_email(urldecode($_GET['old_email'])) : '';
    $new_email = isset($_GET['new_email']) ? sanitize_email(urldecode($_GET['new_email'])) : '';

    if ($old_email && $new_email && $old_email === get_option('admin_email')) {
        delete_option('new_admin_email');
        wp_die('The admin email change request has been revoked.', 'Email Change Revoked', array('response' => 200));
    } else {
        wp_die('Invalid email addresses.', 'Email Change Revoked', array('response' => 200));
    }
}