<!-- templates/form.php -->
<div class="">
    <div class="main-contain">
        <div class="main-col">
            <div class="user-contact roboto-regular">
				<img src="<?php echo get_option('companylogo'); ?>" width="200">
				<p>
					<?php echo get_option('companyaddress'); ?>
				</p>
				<p>
					<a href="tel:<?php echo get_option('companyphone'); ?>"><?php echo get_option('companyphone'); ?></a>
				</p>
				<p>
					<a href="mailto:<?php echo get_option('companyemail'); ?>"><?php echo get_option('companyemail'); ?></a>
				</p>
				<div>
					<?php echo get_option('companylocation'); ?>
				</div>
			</div>
        </div>
        <div class="main-col">
			<h2 class="roboto-bold">
				Get in touch
			</h2>
            <form id="bitss-pre-form" method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                <?php
					if(get_option('nameField') == 1) {
				?>
                <div class="input-block">
                    <label for="name" class="bitss-label roboto-regular">Name <?php if(get_option('nameFieldRequired') == 1){ echo '*'; }?></label>
					<input type="text" class="input-class" id="name" name="name" pattern="[A-Za-z ]+" title="Only letter and space are allowed." <?php if(get_option('nameFieldRequired') == 1){ echo 'required'; }?>>
                </div>
                <?php } ?>

                <?php
					if(get_option('emailField') == 1) {
				?>
                <div class="input-block">
                    <label for="email" class="bitss-label roboto-regular">Email <?php if(get_option('emailFieldRequired') == 1){ echo '*'; }?></label>
					<input type="text" class="input-class" id="email" name="email" pattern="[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$" title="Please enter a valid email address." <?php if(get_option('emailFieldRequired') == 1){ echo 'required'; }?>>
                </div>
                <?php } ?>

                <?php
					if(get_option('phoneField') == 1) {
				?>
                <div class="input-block">
                    <label for="phone" class="bitss-label roboto-regular">Phone <?php if(get_option('phoneFieldRequired') == 1){ echo '*'; }?></label>
                    <div class="custom-select-group mb3">
						<div class="custom-select">
							<?php
								$ch = curl_init();
								curl_setopt($ch, CURLOPT_URL, 'https://bitts.fr/api-phone/');
								curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
								$response = curl_exec($ch);
								if (curl_errno($ch)) {
									echo 'cURL error: ' . curl_error($ch);
								}
								curl_close($ch);
								$data = json_decode($response, true);

								if ($data) {
									if (isset($data) && is_array($data)) {
										echo '<select id="phonecode" name="phonecode" class="" required>';
										foreach ($data as $country) {
											if (isset($country['phone'])) {
												echo '<option value="'.$country['phone'].'" data-phone-length="'.$country['phoneLength'].'">'.$country['country'].'('.$country['phone'].')</option>';
											}
										}
										echo '</select>';
									} else {
										echo 'No data found.';
									}
								} else {
									echo 'Failed to parse JSON response.';
								}
							?>
						</div>
						<input type="text" class="input-class" id="phone" name="phone" pattern="^[0-9+]+$" title="Only numbers are allowed." <?php if(get_option('phoneFieldRequired') == 1){ echo 'required'; }?>>
                    </div>
                </div>
                <?php } ?>

                <?php
					if(get_option('countryField') == 1) {
				?>
                <div class="input-block">
                    <label for="country" class="bitss-label roboto-regular">Country <?php if(get_option('countryFieldRequired') == 1){ echo '*'; }?></label>
						<div class="custom-select">
						<?php
							$ch = curl_init();
							curl_setopt($ch, CURLOPT_URL, 'https://bitts.fr/api-phone/');
							curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
							$response = curl_exec($ch);
							if (curl_errno($ch)) {
								echo 'cURL error: ' . curl_error($ch);
							}
							curl_close($ch);
							$data = json_decode($response, true);

							if ($data) {
								if (isset($data) && is_array($data)) {
									echo '<select id="country" name="country" class="" aria-describedby="countryHelp" required>';
									foreach ($data as $country) {
										if (isset($country['country'])) {
											echo '<option value="'.$country['country'].'">' . $country['country'] . '</option>';
										}
									}
									echo '</select>';
								} else {
									echo 'No data found.';
								}
							} else {
								echo 'Failed to parse JSON response.';
							}
						?> 
						</div>
                </div>
                <?php } ?>

                <?php
					if(get_option('companyField') == 1) {
				?>
                <div class="input-block">
                    <label for="company" class="bitss-label roboto-regular">Company Name <?php if(get_option('companyFieldRequired') == 1){ echo '*'; }?></label>
					<input type="text" class="input-class" id="company" name="company" pattern="[A-Za-z ]+" title="Only letter and space are allowed." <?php if(get_option('companyFieldRequired') == 1){ echo 'required'; }?>>
                </div>
                <?php } ?>

                <?php
					if(get_option('hearField') == 1) {
				?>
                <div class="input-block">
                    <label for="hear" class="bitss-label roboto-regular">How do you hear about us? <?php if(get_option('hearFieldRequired') == 1){ echo '*'; }?></label>
					<div class="custom-select">
                    <select id="hear" name="hear" class="" aria-describedby="findHelp"
                        <?php if(get_option('hearFieldRequired') == 1){ echo 'required'; }?>>
                        <option value="" selected>Please select option</option>
                        <option value="search">Search Engine(Google, Bing, etc.)</option>
                        <option value="social">Social Media(Facebook, Twitter, etc.)</option>
                        <option value="recommend">Recommended by others</option>
                        <option value="others">Others</option>
                    </select>
					</div>
                </div>
                <?php } ?>

                <?php
					if(get_option('connectField') == 1) {
				?>
                <div class="input-block">
                    <label for="connect" class="bitss-label roboto-regular">Contact me through? <?php if(get_option('connectFieldRequired') == 1){ echo '*'; }?></label>
					<div class="custom-select">
                    <select id="connect" name="connect" class="" <?php if(get_option('connectFieldRequired') == 1){ echo 'required'; }?>>
                        <option value="" selected>Please select option</option>
                        <?php if(get_option('mailField') == 1){ echo '<option value="Email">Email</option>'; }?>
                        <?php if(get_option('phoneField') == 1){ echo '<option value="Phone">Phone</option>'; }?>
						<?php if(get_option('skypeField') == 1){ echo '<option value="Skype">Skype</option>'; }?>
						<?php if(get_option('whatsappField') == 1){ echo '<option value="Whatsapp">Whatsapp</option>'; }?>
						<?php if(get_option('facebookField') == 1){ echo '<option value="Facebook">Facebook</option>'; }?>
                    </select>
					</div>
                </div>
                <?php } ?>

                <?php
					if(get_option('skypeField') == 1) {
				?>
                <div class="input-block">
                    <label for="skype" class="bitss-label roboto-regular">Skype Id (For Contact) <?php if(get_option('skypeFieldRequired') == 1){ echo '*'; }?></label>
                    <input type="text" class="input-class" id="skype" name="skype" <?php if(get_option('skypeFieldRequired') == 1){ echo 'required'; }?>>
                </div>
                <?php } ?>

                <?php
					if(get_option('facebookField') == 1) {
				?>
                <div class="input-block">
                    <label for="facebook" class="bitss-label roboto-regular">Facebook URL(For Contact) <?php if(get_option('facebookFieldRequired') == 1){ echo '*'; }?></label>
                    <input type="text" class="input-class" id="facebook" name="facebook" <?php if(get_option('facebookFieldRequired') == 1){ echo 'required'; }?>>
                </div>
                <?php } ?>

                <?php
					if(get_option('whatsappField') == 1) {
				?>
                <div class="input-block">
                    <label for="whatsapp" class="bitss-label roboto-regular">Whatsapp Number (For Contact) <?php if(get_option('whatsappFieldRequired') == 1){ echo '*'; }?></label>
                    <input type="text" class="input-class" id="whatsapp" name="whatsapp" <?php if(get_option('whatsappFieldRequired') == 1){ echo 'required'; }?>>
					<div id="whatsappHelp" class="form-text text-black-50"><small>Please input whatsapp number with country code without + sign.</small></div>
                </div>
                <?php } ?>


                <?php
					if(get_option('subjectField') == 1) {
				?>
                <div class="input-block">
                    <label for="subject" class="bitss-label roboto-regular">Subject/Query for <?php if(get_option('subjectFieldRequired') == 1){ echo '*'; }?></label>
                    <input type="text" name="subject" id="subject" class="input-class" <?php if(get_option('subjectFieldRequired') == 1){ echo 'required'; }?>>
                </div>
                <?php } ?>

                <?php
					if(get_option('messageField') == 1) {
				?>
                <div class="input-block">
                    <label for="message" class="bitss-label roboto-regular">Message <?php if(get_option('messageFieldRequired') == 1){ echo '*'; }?></label>
                    <textarea name="message" id="message" rows="7" class="form-label" <?php if(get_option('messageFieldRequired') == 1){ echo 'required'; }?>></textarea>
                </div>
                <?php } ?>

                <?php
					if(get_option('mailingField') == 1) {
				?>
                <div class="input-block">
                    <label for="mailing" class="bitss-label roboto-regular">Mailing Address <?php if(get_option('mailingFieldRequired') == 1){ echo '*'; }?></label>
                    <textarea name="mailing" id="mailing" rows="7" class="form-label" <?php if(get_option('mailingFieldRequired') == 1){ echo 'required'; }?>></textarea>
                </div>
                <?php } ?>
				
				<input type="hidden" name="action" value="preselect_form_submit">
				<input type="hidden" id="tCheck" name="tCheck" value="<?php echo time(); ?>">
				<input type="text" id="hidden_field" name="hidden_field" style="display: none;">
				<?php wp_nonce_field('preselect_form_submit', 'preselect_form_nonce'); ?>
				
				<?php
					$cap_username = get_option('capUsername');
					$cap_password = get_option('capKey');
				
					if (!empty($cap_username) || !empty($cap_password)) {
						$apiUrl = 'https://bitts.fr/preselect/captcha/api.php';
						$username = get_option('capUsername');
						$password = get_option('capKey');
						$servername = $_SERVER['SERVER_NAME'];
						$data = array(
							'username' => $username,
							'password' => $password,
							'servername' => $servername,
						);
						$ch = curl_init($apiUrl);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($ch, CURLOPT_POST, 1);
						curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
						curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
						$response = curl_exec($ch);
						if ($response === false) {
							echo 'Error: ' . curl_error($ch);
						} else {
							$responseData = json_decode($response, true);

							if (isset($responseData['error'])) {
								// Handle API error here
								echo '<div class="roboto-regular error-license"><i class="bi bi-slash-circle"></i> Unable to validate license key. Please check that you entered valid license key. To purchase a license visit <a href="https://bitss.fr" target="_blank">bitss.fr</a> or contact <a href="mailto:support@bobosohomail.com">support@bobosohomail.com</a>.</div>';
							} else {
								if (get_option('capType') == 'math') {
									echo '<label class="input-label">BITSS Captcha: *</label><br>';
									$numberone = rand(1, 99);	
									$numbertwo = rand(1, 99);								
									$text = strval($numberone) . ' + ' . strval($numbertwo);
									$img = imagecreate(75, 25);
									$textbgcolor = imagecolorallocate($img, 173, 230, 181);
									$textcolor = imagecolorallocate($img, 0, 0, 0);
									imagestring($img, 5, 10, 5, $text, $textcolor);
									ob_start();
									imagepng($img);
									printf('<img class="cap-math mb3" src="data:image/png;base64,%s"/ width="100">', base64_encode(ob_get_clean()));
									echo '<input type="text" name="numbersum" id="numbersum" class="input-block" required>';
									echo '<input type="hidden" name="numberone" value="' . $numberone . '">';
									echo '<input type="hidden" name="numbertwo" value="' . $numbertwo . '">';
								} else {
									echo '<label class="input-label">BITSS Captcha: *</label><br>';
									$text = substr(md5(time()), 0, 7);
									$img = imagecreate(75, 25);
									$textbgcolor = imagecolorallocate($img, 173, 230, 181);
									$textcolor = imagecolorallocate($img, 0, 0, 0);
									imagestring($img, 5, 10, 5, $text, $textcolor);
									ob_start();
									imagepng($img);
									printf('<img class="cap-math mb3" src="data:image/png;base64,%s"/ width="100">', base64_encode(ob_get_clean()));
									echo '<input type="text" name="textsum" id="textsum" class="input-block" required>';
									echo '<input type="hidden" name="textone" value="' . $text . '">';
								}								
							}
						}
					}
					
					$spamuname = get_option('spamUsername');
					$spampword = get_option('spamKey');

					if (!empty($spamuname) || !empty($spampword)) {
						$apiUrl = 'https://bitts.fr/preselect/spam/api.php';
						$susername = get_option('spamUsername');
						$spassword = get_option('spamKey');
						$sservername = $_SERVER['SERVER_NAME'];
						$data = array(
							'username' => $susername,
							'password' => $spassword,
							'servername' => $sservername,
						);
						$ch = curl_init($apiUrl);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($ch, CURLOPT_POST, 1);
						curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
						curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
						$response = curl_exec($ch);
						if ($response === false) {
							echo 'Error: ' . curl_error($ch);
						} else {
							$responseData = json_decode($response, true);

							if (isset($responseData['error'])) {
								// Handle API error here
								echo '<div class="roboto-regular error-license"><i class="bi bi-slash-circle"></i> Unable to validate license key. Please check that you entered valid license key. To purchase a license visit <a href="https://bitss.fr" target="_blank">bitss.fr</a> or contact <a href="mailto:support@bobosohomail.com">support@bobosohomail.com</a>.</div>';
							} else {
								
							}
						}
					}
				?>

				<div class="roboto-regular note"><i class="bi bi-info-circle-fill"></i> Note: Before submit, please make sure that you fill/select all required fields marked by star(*).</div>
				
				<div id="preselect-form-message" class="preselect-form-message roboto-regular"></div>
                
				<button class="roboto-medium" type="submit"> SUBMIT </button>
							
				<?php 
				$valuecheck = esc_attr(get_option('creditShow'));
				if ($valuecheck == 1) {
				?>
					<div class="credit-info">
						<a href="https://bitss.fr" target="_blank" rel="nofollow">
							<img src="<?php echo plugin_dir_url(__FILE__) . 'bitss_icon.png'; ?>" width="30">
						</a>
						<small class="roboto-regular">This form is powered by BITSS</small>
						<small class="roboto-regular">&copy; <?php echo date('Y'); ?> BITSS by BFIN. All rights reserved.</small>
					</div>
				<?php
				} else {
					
				}
				?>
            </form>
        </div>
    </div>
</div>
