<?php
/**
 * BITSS WAP for WordPress
 * Powered by BFINIT Ltd.
 * Author: BITSS Team
 * Maintain by: M Rahman Sayed
 * URL: https://github.com/mrahmansayed
 */

add_action('admin_init', function() {
	register_setting('bitss-settings-group', 'ip_block_level');
});

add_action('wp_ajax_get_blacklist_ips', 'get_blacklist_ips');
function get_blacklist_ips() {
	global $wpdb;
	$table_name = $wpdb->prefix . 'ip_blacklist';
	$admin_query = "SELECT * FROM $table_name";
	$datum = $wpdb->get_results($admin_query);

	$data = [];
	foreach ($datum as $data_item) {
		$data[] = [
			'ip_address' => esc_html($data_item->ip_address),
			'ip_name' => esc_html($data_item->ip_name),
			'ip_count' => esc_html($data_item->ip_count),
			'ip_add' => esc_html($data_item->attempt_timestamp),
		];
	}

	wp_send_json([
		'data' => $data,
	]);
}

function blacklist_manage_settings() {
	global $wpdb;
	// start
	if (isset($_POST['add-blacklist-ip'])) {
		$ip = sanitize_text_field($_POST['ip']);
		$ip_name = sanitize_text_field($_POST['ip-name'] ?? '') ?: 'Unknown';
		$ip_count = sanitize_text_field($_POST['ip-count'] ?? '') ?: '3';
		// $ip_count = sanitize_text_field($_POST['ip-count']);
		$table_blacklist = $wpdb->prefix . 'ip_blacklist';
		$table_whitelist = $wpdb->prefix . 'ip_whitelist';
		$ip_exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_blacklist WHERE ip_address = %s", $ip));
		if (!$ip_exists) {
			$ip_whitelist_exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_whitelist WHERE ip_address = %s", $ip));
			if (!$ip_whitelist_exists) {
				$wpdb->insert(
					$table_blacklist,
					array(
						'ip_address' => $ip,
						'ip_name' => $ip_name,
						'ip_count' => $ip_count,
						'attempt_timestamp' => current_time('mysql'),
					),
					array(
						'%s',
						'%s',
						'%d',
						'%s',
					)
				);
				echo '<div class="notice notice-success is-dismissible"><p>IP address added blacklist successfully.</p></div>';
			} else {
				$wpdb->delete($table_whitelist, array('ip_address' => $ip));
				$wpdb->insert(
					$table_blacklist,
					array(
						'ip_address' => $ip,
						'ip_name' => $ip_name,
						'ip_count' => $ip_count,
						'attempt_timestamp' => current_time('mysql'),
					),
					array(
						'%s',
						'%s',
						'%d',
						'%s',
					)
				);
				echo '<div class="notice notice-success is-dismissible"><p>IP address removed form whitelist and added blacklist successfully.</p></div>';
			}
		} else {
			echo '<div class="notice notice-error is-dismissible"><p>The IP address already in blacklist.</p></div>';
		}
	}
	// end
	if (isset($_POST['remove-blacklist-ip'])) {
		$ip = sanitize_text_field($_POST['ip']);
		$table_blacklist = $wpdb->prefix . 'ip_blacklist';
		$wpdb->delete($table_blacklist, array('ip_address' => $ip));
		echo '<div class="notice notice-success is-dismissible"><p>IP address unblock successfully.</p></div>';
	}
?>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script>
	jQuery(document).ready(function($) {
		$('#blacklist-ip-table').DataTable({
			"ajax": {
				"url": ajaxurl, // WordPress-specific global variable for Ajax URL
				"type": "POST",
				"data": {
					"action": "get_blacklist_ips" // Ajax action name
				}
			},
			"columns": [
				{ "data": "ip_address" },
				{ "data": "ip_name" },
				{ "data": "ip_count" },
				{ "data": "ip_add" },
			],
			"paging": true,
			"searching": true
		});
	});
</script>

<div class="wrap">
	<div id="col-container" class="wp-clearfix">
		<h1>Blacklist IP Management</h1>
	</div>
</div>
<div class="wrap">
	<div id="col-container" class="wp-clearfix">
		<div id="col-left">
			<div class="col-wrap">
				<?php
	$active_tab = isset( $_GET['tab'] ) ? $_GET['tab'] : 'add';
				?>
				<h2 class="nav-tab-wrapper">
					<a href="?page=blacklist-ip&tab=add" class="nav-tab <?php echo $active_tab == 'add' ? 'nav-tab-active' : ''; ?>">Add to Blacklist</a>
					<a href="?page=blacklist-ip&tab=level" class="nav-tab <?php echo $active_tab == 'level' ? 'nav-tab-active' : ''; ?>">IP Block Level</a>
					<a href="?page=blacklist-ip&tab=unblock" class="nav-tab <?php echo $active_tab == 'unblock' ? 'nav-tab-active' : ''; ?>">Unblock IP</a>
				</h2>
				<div class="tabs-content">
					<?php if( $active_tab == 'add' ): ?>
					<div class="form-wrap">
						<form method="post" action="" class="custom-form">
							<table class="form-table">
								<tbody>
									<tr>
										<th scope="row">IP Address *</th>
										<td><input type="text" name="ip" placeholder="192.168.0.1" required/></td>
									</tr>
									<tr>
										<th scope="row">Name <small><br>(Default: Unknown)</small></th>
										<td><input type="text" name="ip-name" placeholder="Unknown" /></td>
									</tr>
									<tr>
										<th scope="row">Block Level <small><br>(Default: 3)</small></th>
										<td><input type="number" name="ip-count" min="1" placeholder="More than 1"/></td>
									</tr>
								</tbody>
							</table>
							<input type="submit" name="add-blacklist-ip" class="button button-primary" value="Add IP" />
						</form>
					</div>

					<?php elseif( $active_tab == 'level' ): ?>
					<div class="form-wrap">
						<form method="post" action="options.php">
							<?php
	settings_fields('bitss-settings-group');
	do_settings_sections('bitss-settings-group');
							?>
							<table class="form-table">
								<tbody>
									<tr>
										<th colspan="2">
											<p>IP block level use to block the access for the listed ip from that level. You can set your own block level. Input a number as a block level (by default: 3). So when an ip flag level will be same or more than your input level, it will block the access automatically.</p>
										</th>
									</tr>
									<tr>
										<th>
											Block Level
										</th>
										<td>
											<input type="text" name="ip_block_level" value="<?php echo esc_attr(get_option('ip_block_level', '') ?: 3); ?>" />
										</td>
									</tr>
								</tbody>
							</table>
							<input type="submit" name="submit_block_level_value" class="button button-primary" value="Save block level" />

						</form>
					</div>

					<?php elseif( $active_tab == 'unblock' ): ?>
					<div class="form-wrap">
						<form method="post" action="" id="unblock-form">
							<table class="form-table">
								<tbody>
									<tr>
										<th scope="row">IP Address *</th>
										<td><input type="text" name="ip" placeholder="192.168.0.1" required/></td>
									</tr>
								</tbody>
							</table>
							<input type="submit" name="remove-blacklist-ip" class="button button-primary" value="Unblock IP" />
						</form>
					</div>
					<script>
						document.getElementById('unblock-form').addEventListener('submit', function(event) {
							var confirmed = confirm('Are you sure you want to unblock this IP address?');
							if (!confirmed) {
								event.preventDefault(); // Prevent form submission if not confirmed
							}
						});
					</script>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<div id="col-right">
			<div class="col-wrap" style="background: #fff;padding: 20px;border-radius: 5px;border: 1px solid #ddd;">
				<table id="blacklist-ip-table" class="cell-border">
					<thead>
						<tr>
							<th>IP Address</th>
							<th>Name</th>
							<th>Block Level</th>
							<th>Date</th>
						</tr>
					</thead>
					<tbody>
						<!-- DataTables will populate this via Ajax -->
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<?php
}