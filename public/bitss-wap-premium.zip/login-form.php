<?php
/**
 * BITSS WAP for WordPress
 * Powered by BFINIT Ltd.
 * Author: BITSS Team
 * Maintain by: M Rahman Sayed
 * URL: https://github.com/mrahmansayed
 */

// Login logo return url
add_filter('login_headerurl', function() {
    return home_url();
});

// Custom login logo instead of wordpress default.
add_action('login_head', function() {
    echo "
        <style>
            .login h1 a {
                background-image: url(https://bfin.technology/wp-content/uploads/2024/06/bfin-it-1.svg);
                background-size: auto;
                background-position: center top;
                background-repeat: no-repeat;
                color: #3c434a;
                height: auto;
                font-size: 40px;
                font-weight: 400;
                line-height: 1.3;
                margin: 0 auto 25px;
                padding: 0;
                text-decoration: none;
                width: 140px;
                text-indent: -9999px;
                outline: 0;
                overflow: hidden;
                display: block;
            }
        </style>
    ";
});


// Redirect to homepage from all those actions
if (get_option('disable_lost_password') == 1) {
    // Disable access to the lost password URL
    add_action('login_form_lostpassword', function() {
        if (isset($_GET['action'])) {
            if ($_GET['action'] == 'lostpassword' || $_GET['action'] == 'checkemail' || $_GET['action'] == 'confirm_admin_email' || $_GET['action'] == 'confirmaction' || $_GET['action'] == 'entered_recovery_mode' || $_GET['action'] == 'postpass' || $_GET['action'] == 'register' || $_GET['action'] == 'resetpass' || $_GET['action'] == 'retrievepassword' || $_GET['action'] == 'rp') {
                wp_redirect(home_url()); // Redirect to home page
                exit;
            }
        }
    });

    // Hide the "Lost your password?" link on the login page
    add_action('login_enqueue_scripts', function() {
        echo '<style>
        .login #nav a[href*="lostpassword"] {
            display: none;
        }
    </style>';
    });
}