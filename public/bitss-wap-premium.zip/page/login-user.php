<?php
// Add this at the top of your file to handle logout requests
add_action('wp_loaded', function() {
    if (isset($_GET['custom_logout_user_id'])) {
        $user_id_to_logout = intval($_GET['custom_logout_user_id']);
        
        if ($user_id_to_logout) {
            wp_logout_user($user_id_to_logout);
            // wp_redirect(home_url()); // Redirect to homepage or any other page after logout
			// Get the referring URL
            $redirect_url = wp_get_referer();
            
            // If there's no referrer, redirect to the homepage
            if (!$redirect_url) {
                $redirect_url = home_url();
            }
            
            wp_redirect($redirect_url); // Redirect to the referring URL or homepage
            exit;
        }
    }
});

// Function to log out a specific user
function wp_logout_user($user_id) {
    $user = get_userdata($user_id);
    if ($user) {
        // Destroy the user's session tokens
        delete_user_meta($user_id, 'session_tokens');
    }
}

function login_users_settings() {
	global $wpdb;

    // Get all user IDs with active session tokens
    $logged_in_users = $wpdb->get_col("
        SELECT user_id
        FROM $wpdb->usermeta
        WHERE meta_key = 'session_tokens'
    ");
?>
<style>
	table#loggedin-user {
		width: 100%;
		border-collapse: collapse;
	}
	table#loggedin-user th, table#loggedin-user td {
		border: 1px solid black;
		padding: 10px;
		text-align: center;
	}
</style>
<div class="wrap">
	<div id="col-container" class="wp-clearfix">
		<h1>Current Logged In User Data</h1>
	</div>
</div>
<div class="wrap">
    <div class="col-wrap" style="background: #fff; padding: 20px; border-radius: 5px; border: 1px solid #ddd;">
        <table id="loggedin-user">
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Display Name</th>
                    <th>IP</th>
					<th>WP ID</th>
                    <th>Role</th>
                    <th>Registered On</th>
					<th>Last login time</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>	
				<?php
                    if (!empty($logged_in_users)) {
                        foreach ($logged_in_users as $user_id) {
                            $user_info = get_userdata($user_id);
                            $user_ip = ''; // Get user IP if needed
                            
                            // Get user roles as an array
                            $user_roles = $user_info->roles;

                            // Check if $user_roles is an array
                            if (is_array($user_roles)) {
                                $user_roles_string = implode(', ', $user_roles);
                            } else {
                                $user_roles_string = ''; // Handle case where roles are not an array
                            }
							$last_login_time = get_user_meta($user_id, 'last_login_time', true);

							if (!empty($last_login_time)) {
								// Calculate time difference
								$last_login_timestamp = strtotime($last_login_time);
								$current_timestamp = current_time('timestamp');
								$time_diff = $current_timestamp - $last_login_timestamp;

								// Convert to minutes or hours ago
								if ($time_diff < 60) {
									$time_ago = $time_diff . ' seconds ago';
								} elseif ($time_diff < 3600) {
									$time_ago = round($time_diff / 60) . ' minutes ago';
								} else {
									$time_ago = round($time_diff / 3600) . ' hours ago';
								}
							} else {
								$time_ago = 'N/A';
							}
							$last_login_ip = get_user_meta($user_id, 'last_login_ip', true);
                            ?>
                            <tr> 
                                <td><?php echo esc_html($user_info->user_login); ?></td>
                                <td><?php echo esc_html($user_info->user_email); ?></td>
                                <td><?php echo esc_html($user_info->display_name); ?></td>
                                <td><?php echo esc_html($last_login_ip); ?></td>
								<td><?php echo esc_html($user_info->ID); ?></td>
                                <td><?php echo esc_html($user_roles_string); ?></td>
                                <td><?php echo esc_html($user_info->user_registered); ?></td>
								<td><?php echo esc_html($time_ago); ?></td>
                                <td>
                                    <a href="<?php echo esc_url(add_query_arg('custom_logout_user_id', $user_info->ID)); ?>" class="button">Logout</a>
                                </td>
                            </tr>
                            <?php
                        }
                    } else {
                        echo '<tr><td colspan="8">No users are currently logged in.</td></tr>';
                    }
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php
}


/*
function login_users_settings() {
	global $wpdb;

    // Get all user IDs with active session tokens
    $logged_in_users = $wpdb->get_col("
        SELECT user_id
        FROM $wpdb->usermeta
        WHERE meta_key = 'session_tokens'
    ");

    if (!empty($logged_in_users)) {
        // Start the table with classes for styling
        echo '<table class="logged-in-users-table">';
        echo '<thead><tr><th>User ID</th><th>Username</th><th>Email</th></tr></thead>';
        echo '<tbody>';

        foreach ($logged_in_users as $user_id) {
            $user_info = get_userdata($user_id);
            echo '<tr>';
            echo '<td>' . esc_html($user_id) . '</td>';
            echo '<td>' . esc_html($user_info->user_login) . '</td>';
            echo '<td>' . esc_html($user_info->user_email) . '</td>';
            echo '</tr>';
        }

        echo '</tbody>';
        echo '</table>';
    } else {
        echo 'No users are currently logged in.';
    }
}




function get_user_ip() {
    if ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
        // IP address from shared internet
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
        // IP address passed from a proxy
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        // IP address from remote address
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

// Include necessary WordPress functions
if ( ! function_exists( 'wp_logout' ) ) {
    require_once( ABSPATH . 'wp-includes/pluggable.php' );
}

// Logout function based on user ID
function custom_logout_user_by_id( $user_id ) {
    // Check if the current user is the same as the one to be logged out
    if ( get_current_user_id() == $user_id ) {
        wp_logout();
        wp_redirect( home_url() ); // Redirect to the homepage or any other page
        exit;
    }
}

// Handle the logout action
if ( isset( $_GET['logout_user_id'] ) && is_numeric( $_GET['logout_user_id'] ) ) {
    custom_logout_user_by_id( $_GET['logout_user_id'] );
}

function login_users_settings() {
    $current_user = wp_get_current_user();
    
    // Check if a user is logged in
    if ( $current_user->exists() ) {
        // Get user IP address
        $user_ip = get_user_ip();

        // Get user roles
        $user_roles = $current_user->roles;
        ?>
		<style>
			table#loggedin-user {
				width: 100%;
				border-collapse: collapse;
			}
			table#loggedin-user th, table#loggedin-user td {
				border: 1px solid black;
				padding: 10px;
			}
		</style>
		<div class="wrap">
			<div id="col-container" class="wp-clearfix">
				<h1>Current Logged In Users</h1>
			</div>
    	</div>
        <div class="wrap">
            <div class="col-wrap" style="background: #fff; padding: 20px; border-radius: 5px; border: 1px solid #ddd;">
                <table id="loggedin-user">
                    <thead>
                        <tr>
                            <th>WP User ID</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Display Name</th>
                            <th>IP</th>
                            <th>Roles</th>
                            <th>Registered On</th>
							<th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo $current_user->ID; ?></td>
                            <td><?php echo $current_user->user_login; ?></td>
                            <td><?php echo $current_user->user_email; ?></td>
                            <td><?php echo $current_user->display_name; ?></td>
                            <td><?php echo $user_ip; ?></td>
                            <td><?php echo implode( ', ', $user_roles ); ?></td>
                            <td><?php echo $current_user->user_registered; ?></td>
							<td>
								<a href="<?php echo add_query_arg( 'logout_user_id', $current_user->ID ); ?>" class="button">Logout</a>
							</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    } else {
        echo 'No user is currently logged in.';
    }
}

function get_all_logged_in_users() {
    if (!is_user_logged_in()) {
        return array();
    }

    global $wpdb;
    $session_table = $wpdb->prefix . 'wp_sessions';
    $query = "SELECT DISTINCT user_id FROM $session_table WHERE session_value LIKE '%logged_in%'";

    $results = $wpdb->get_results($query, ARRAY_A);

    $logged_in_users = array();
    foreach ($results as $result) {
        $logged_in_users[] = $result['user_id'];
    }

    return $logged_in_users;
}

$logged_in_users = get_all_logged_in_users();

if (!empty($logged_in_users)) {
    echo 'Logged-in user IDs: <br>';
    foreach ($logged_in_users as $user_id) {
        echo $user_id . '<br>';
    }
} else {
    echo 'No users are currently logged in.';
}
*/


