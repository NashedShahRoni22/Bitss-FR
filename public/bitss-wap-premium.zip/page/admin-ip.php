<?php
/**
 * BITSS WAP for WordPress
 * Powered by BFINIT Ltd.
 * Author: BITSS Team
 * Maintain by: M Rahman Sayed
 * URL: https://github.com/mrahmansayed
 */

add_action('wp_ajax_get_admin_ips', 'get_admin_ips');
function get_admin_ips() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ip_admin';
    $admin_query = "SELECT * FROM $table_name";
    $datum = $wpdb->get_results($admin_query);

    $data = [];
    foreach ($datum as $data_item) {
        $data[] = [
            'ip_address' => esc_html($data_item->ip_address),
            'ip_name' => esc_html($data_item->ip_name),
            'ip_valid' => esc_html($data_item->valid_till),
            'ip_add' => esc_html($data_item->attempt_timestamp),
            'failed_login_count' => esc_html($data_item->failed_login_count),
        ];
    }

    wp_send_json([
        'data' => $data,
    ]);
}

function login_access_settings() {
    global $wpdb;
    // start
    if (isset($_POST['add-admin-ip'])) {
        $admin_ip = sanitize_text_field($_POST['admin-ip']);
        $admin_name = sanitize_text_field($_POST['admin-name'] ?? '') ?: 'Unknown';
        $valid_till = sanitize_text_field($_POST['valid-till']);
        $table_name = $wpdb->prefix . 'ip_admin';
        $ip_exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE ip_address = %s", $admin_ip));
        if (!$ip_exists) {
            $wpdb->insert(
                $table_name,
                array(
                    'ip_address' => $admin_ip,
                    'ip_name' => $admin_name,
                    'valid_till' => $valid_till,
                    'failed_login_count' => 0,
                    'attempt_timestamp' => current_time('mysql'),
                ),
                array(
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                )
            );
            echo '<div class="notice notice-success is-dismissible"><p>IP address added for admin access successfully.</p></div>';
        } else {
            echo '<div class="notice notice-warning is-dismissible"><p>This ip address already exits for admin access.</p></div>';
        }
    }
    // end
    if (isset($_POST['remove-admin-ip'])) {
        $ip = sanitize_text_field($_POST['ip']);
        $table_blacklist = $wpdb->prefix . 'ip_admin';
        $wpdb->delete($table_blacklist, array('ip_address' => $ip));
		echo '<div class="notice notice-success is-dismissible"><p>IP address remove successfully.</p></div>';
    }
    ?>


    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script>
        jQuery(document).ready(function($) {
            $('#admin-ip-table').DataTable({
                "ajax": {
                    "url": ajaxurl, // WordPress-specific global variable for Ajax URL
                    "type": "POST",
                    "data": {
                        "action": "get_admin_ips" // Ajax action name
                    }
                },
                "columns": [
                    { "data": "ip_address" },
                    { "data": "ip_name" },
                    { "data": "ip_valid" },
                    { "data": "ip_add" },
                    { "data": "failed_login_count" },
                ],
                "paging": true,
                "searching": true
            });


        });
    </script>

    <div class="wrap">
        <div id="col-container" class="wp-clearfix">
            <h1>Admin IP Management</h1>
        </div>
    </div>
    <div class="wrap">
        <div id="col-container" class="wp-clearfix">
            <div id="col-left">
                <div class="col-wrap">
                    <b>Note: If admin ip failed login count is being more than 2(two). That ip will block directly without warning. You can not reset the count. Just remove the ip and add it again for the access.</b>
                    <?php
                    $active_tab = isset( $_GET['tab'] ) ? $_GET['tab'] : 'add';
                    ?>
                    <h2 class="nav-tab-wrapper">
                        <a href="?page=login-access&tab=add" class="nav-tab <?php echo $active_tab == 'add' ? 'nav-tab-active' : ''; ?>">Add Admin Login IP</a>
                        <a href="?page=login-access&tab=remove" class="nav-tab <?php echo $active_tab == 'remove' ? 'nav-tab-active' : ''; ?>">Remove IP</a>
                    </h2>
                    <?php if( $active_tab == 'add' ): ?>
                        <div class="form-wrap">
                            <form method="post" action="" class="custom-form">
                                <table class="form-table">
                                    <tbody>
                                    <tr>
                                        <th scope="row">IP Address *</th>
                                        <td><input type="text" name="admin-ip" placeholder="192.168.0.1" style="width:100%" required/></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Name <small><br>(Default: Unknown)</small></th>
                                        <td><input type="text" name="admin-name" placeholder="Unknown" style="width:100%" /></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Valid till *</th>
                                        <td><input type="datetime-local" id="valid-till" name="valid-till" required></td>
                                    </tr>
                                    </tbody>
                                </table>
                                <input type="submit" name="add-admin-ip" class="button button-primary" value="Add IP" />
                            </form>
                        </div>
                    <?php elseif( $active_tab == 'remove' ): ?>
                        <div class="form-wrap">
                            <form method="post" action="" id="unblock-form">
                                <table class="form-table">
                                    <tbody>
                                    <tr>
                                        <th scope="row">IP Address *</th>
                                        <td><input type="text" name="ip" placeholder="192.168.0.1" required/></td>
                                    </tr>
                                    </tbody>
                                </table>
                                <input type="submit" name="remove-admin-ip" class="button button-primary" value="Remove IP" />
                            </form>
                        </div>
                        <script>
                            document.getElementById('unblock-form').addEventListener('submit', function(event) {
                                var confirmed = confirm('Are you sure you want to remove this IP address?');
                                if (!confirmed) {
                                    event.preventDefault(); // Prevent form submission if not confirmed
                                }
                            });
                        </script>
                    <?php endif; ?>
                </div>
            </div>
            <div id="col-right">
                <div class="col-wrap" style="background: #fff;padding: 20px;border-radius: 5px;border: 1px solid #ddd;">
                    <table id="admin-ip-table" class="cell-border">
                        <thead>
                            <tr>
                                <th>IP Address</th>
                                <th>Name</th>
                                <th>Valid Till</th>
                                <th>Added Date</th>
                                <th>Failed Login Count</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- DataTables will populate this via Ajax -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php
}