var pageLoadedTime;
var credential;
// inital page load
document.addEventListener("DOMContentLoaded", function () {
  pageLoadedTime = new Date().getTime();
  createCaptchaImage();
  fetchForbiddenWords();

  // Clear the input field and error message
  document.getElementById("captcha").style.display = "none";
  document.getElementById("captchaInput").value = "";
  document.getElementById("invalidCaptcha").style.display = "none";
  document.getElementById("invalidMessage").style.display = "none";
  document.getElementById("invalidKey").style.display = "none";
});

// json file load function
async function fetchJsonData(url) {
  try {
    const response = await fetch(url);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching Country JSON :", error);
  }
}

function getRandomNUmber() {
  return Math.floor(Math.random() * 26) + 6;
}

// Function to create a canvas with captcha text and append it as an image
function createCaptchaImage() {
  const captcha1 = getRandomNUmber();
  const captcha2 = getRandomNUmber();
  const captchaSum = captcha1 + captcha2;

  const canvas = document.createElement("canvas");
  canvas.width = 55; // Set the width of the canvas
  canvas.height = 20; // Set the height of the canvas

  const context = canvas.getContext("2d");
  if (!context) return;

  // Style the text
  context.font = "14px Arial";
  context.fillStyle = "black";

  // Center the text
  const text = `${captcha1} + ${captcha2} =`;
  const textWidth = context.measureText(text).width;
  const x = (canvas.width - textWidth) / 2;
  const y = canvas.height / 2;

  // Draw the text on the canvas
  context.fillText(text, x, y);

  // Append the canvas as an image
  const captchaDisplay = document.getElementById("captchaDisplay");
  captchaDisplay.innerHTML = ""; // Clear previous content
  const captchaImage = new Image();
  captchaImage.src = canvas.toDataURL("image/png");
  captchaDisplay.appendChild(captchaImage);

  // Store the correct captcha sum in a data attribute for later validation
  document
    .getElementById("captchaInput")
    .setAttribute("data-correct-captcha", captchaSum);
}

fetchJsonData("./country.json").then((countryJsonData) => {
  var selectElement = document.getElementById("country");

  countryJsonData.forEach(function (country) {
    var option = document.createElement("option");
    option.value = country.name;
    option.text = country.name;
    selectElement.appendChild(option);
  });
});

// suspicious activity function
const checkSuspiciousActivity = () => {
  const submissionTime = new Date().getTime();
  if (submissionTime - pageLoadedTime < 5000) return true;
  return false;
};

const fetchForbiddenWords = async () => {
  const apiUrl = "https://bitts.fr/api.php";

  credential = await fetchJsonData("./credential.json");
  if (!credential || (credential.username === "" && credential.password === ""))
    return;

  const servername = window.location.hostname;

  const data = {
    username: credential.username,
    password: credential.password,
    servername,
  };

  try {
    const response = await fetch(apiUrl, {
      mode: "cors",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    console.log("response", response);
    if (response.ok) {
      document.getElementById("captcha").style.display = "block";
      const result = await response.json();
      return result ?? [];
    } else {
      document.getElementById("captcha").style.display = "none";
      document.getElementById("invalidKey").style.display = "block";
    }
  } catch (error) {
    console.error(error.message);
    document.getElementById("captcha").style.display = "none";
    document.getElementById("invalidKey").style.display = "block";
  }
};

// Function to check forbidden words in the message field
async function checkForbiddenWords() {
  const data = await fetchForbiddenWords();
  const forbiddenWords = data ?? [];

  const messageInput = document.getElementById("message");
  for (const word of forbiddenWords) {
    if (messageInput.value.toLowerCase().includes(word.toLowerCase())) {
      console.log("Submission blocked due to link(s) in the message.");
      return false;
    }
  }

  console.log("Submission allowed.");
  return true;
}

// Function to show the alert
const showAlert = (message) => {
  const alertElement = document.createElement("div");
  alertElement.className = "alert-popup";
  alertElement.textContent = message;
  document.body.appendChild(alertElement);

  setTimeout(() => {
    document.body.removeChild(alertElement);
  }, 3000); // 3000 milliseconds (3 seconds)
};

// FORM SUBMIT
async function submitForm(event) {
  event.preventDefault();

  if (checkSuspiciousActivity()) {
    alert("Suspicious activity detected!");
    return;
  }

  // captcha validate
  const enteredCaptcha = parseInt(
    document.getElementById("captchaInput").value,
    10
  );
  const correctCaptcha = parseInt(
    document
      .getElementById("captchaInput")
      .getAttribute("data-correct-captcha"),
    10
  );
  if (enteredCaptcha !== correctCaptcha) {
    document.getElementById("invalidCaptcha").style.display = "block";
    return;
  }

  // Validate message for forbidden words
  const isMessageValid = await checkForbiddenWords();
  if (!isMessageValid) {
    document.getElementById("invalidMessage").style.display = "block";
    return;
  }

  const formData = {
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    phone: document.getElementById("phone").value,
    country: document.getElementById("country").value,
    subject: document.getElementById("subject").value,
    message: document.getElementById("message").value,
  };

  // send email
  if (credential?.smtpjsConfig?.SecureToken) {
    Email.send({
      ...credential?.smtpjsConfig,
      Subject: formData.subject,
      Body: `<p>
          <strong>Name: </strong>${formData.name} <br>
          <strong>Email: </strong>${formData.email} <br>
          <strong>Phone: </strong>${formData.phone} <br>
          <strong>Country: </strong>${formData.country} <br>
          <strong>Message: </strong>${formData.message} <br>
        </p>`,
    }).then(() => {});
  }

  showAlert("Form submitted successfully!");
  console.log(formData);

  // reset error message
  document.getElementById("invalidCaptcha").style.display = "none";
  document.getElementById("invalidMessage").style.display = "none";
}
