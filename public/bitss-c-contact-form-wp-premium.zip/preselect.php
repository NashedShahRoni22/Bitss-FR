<?php
/*
Plugin Name: BITSS Preselect Contact Form
Plugin URI: https://bitss.fr/
Description: BITSS Preselect Contact Form by BFIN is a clean, secure, plug-&-play contact form for WordPress. Minimal yet flexible, BITSS Preselect Contact Form delivers clean code, solid performance, and ease of use. No frills, no gimmicks, just a straight-up contact form that’s easy to set up and customize. In this contact form you can show/hide the input options easily based on your need.
Version: 2.1
Author: BFIN
Author URI: https://bfin.company/
License: GPLv2 or later
*/

function pre_styles() {
	wp_enqueue_style('pre-form-styles', plugins_url('css/style.css', __FILE__));
}
add_action('wp_enqueue_scripts', 'pre_styles' , 9999);	

function pre_scripts() {
	wp_enqueue_script('pre-form-script', plugins_url('js/script.js', __FILE__), ['jquery'], null, true);
}
add_action('wp_enqueue_scripts', 'pre_scripts');	

add_action( 'admin_enqueue_scripts', 'load_admin_style' );
function load_admin_style() {
    wp_enqueue_style( 'admin_css', plugins_url('css/admin-style.css', __FILE__), false, '1.0.0' );
}

add_action('admin_post_nopriv_preselect_form_submit', 'handle_preselect_form_submission');
add_action('admin_post_preselect_form_submit', 'handle_preselect_form_submission');
add_action('wp_ajax_submit_preselect_form_ajax', 'handle_preselect_form_submission_ajax');
add_action('wp_ajax_nopriv_submit_preselect_form_ajax', 'handle_preselect_form_submission_ajax');

function preselect_form_localize_script() {
    wp_localize_script('pre-form-script', 'preFormAjax', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
		'redirectUrl' => home_url(),
    ));
}
add_action('wp_enqueue_scripts', 'preselect_form_localize_script');

function render_pre_form($atts) {
	ob_start();
	include 'templates/form.php';
	$form_content = ob_get_clean();
	return $form_content;
}
add_shortcode('bitss_preselect_form', 'render_pre_form' );



function handle_preselect_form_submission()
{
	$sTime = $_POST['tCheck'];
	$cTime = time();
	$hidden_field = $_POST['hidden_field'];
	$tDifference = $cTime - $sTime;
	$minDifference = 5;
	if ($tDifference < $minDifference || $hidden_field !== '') {
		wp_send_json_error(" Realtime submission spam detected. Please redo and fully complete the submission again.");
	}
	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		// Define an array to map option names to variable names
		$field_mappings = array(
			'nameField' => 'name',
			'emailField' => 'email',
			'phoneField' => array('phonecode', 'phone'),
			'countryField' => 'country',
			'companyField' => 'company',
			'hearField' => 'hear',
			'connectField' => 'connect',
			'skypeField' => 'skype',
			'facebookField' => 'facebook',
			'whatsappField' => 'whatsapp',
			'subjectField' => 'subject',
			'messageField' => 'message',
			'mailingField' => 'mailing'
		);

		// Loop through the field mappings and sanitize the input
		foreach ($field_mappings as $option => $variables) {
			if (get_option($option) == 1) {
				if (is_array($variables)) {
					foreach ($variables as $variable) {
						${$variable} = sanitize_text_field($_POST[$variable]);
					}
				} else {
					${$variables} = sanitize_text_field($_POST[$variables]);
				}
			}
		}
		
		if(get_option('nameField') == 1) {
			$namevalue = '<strong>Name: </strong>'. $name;
		}
		if(get_option('emailField') == 1) {
			$emailvalue = '<strong>Email: </strong>'. $email;
		}
		if(get_option('phoneField') == 1) {
			$phonevalue = '<strong>Phone: </strong>'. $phonecode .''. $phone;
		}
		if(get_option('countryField') == 1) {
			$countryvalue = '<strong>Country: </strong>'. $country;
		}
		if(get_option('companyField') == 1) {
			$companyvalue = '<strong>Company Name: </strong>'. $company;
		}
		if(get_option('hearField') == 1) {
			$hearvalue = '<strong>How do you hear about us: </strong>'. $hear;
		}
		if(get_option('connectField') == 1) {
			$connectvalue = '<strong>Contact me through: </strong>'. $connect;
		}
		if(get_option('skypeField') == 1) {
			$skypevalue = '<strong>Skype: </strong>'. $skype;
		}
		if(get_option('facebookField') == 1) {
			$facebookvalue = '<strong>Facebook: </strong>'. $facebook;
		}
		if(get_option('whatsappField') == 1) {
			$whatsappvalue = '<strong>Whatsapp: </strong>'. $whatsapp;
		}
		if(get_option('subjectField') == 1) {
			$subjectvalue = '<strong>Subject: </strong>'. $subject;
		}
		if(get_option('messageField') == 1) {
			$messagevalue = '<strong>Message: </strong>'. $message;
		}
		if(get_option('mailingField') == 1) {
			$mailingvalue = '<strong>Mailing Address: </strong>'. $mailing;
		}
		
		$spamapiURL = 'https://bitts.fr/preselect/spam/api.php';
		$spamname = get_option('spamUsername');
		$spampass = get_option('spamKey');
		$servername = $_SERVER['SERVER_NAME'];
		$data = array(
			'username' => $spamname,
			'password' => $spampass,
			'servername' => $servername,
		);
		$ch = curl_init($spamapiURL);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
		$response = curl_exec($ch);
		if ($response === false) {
			echo 'Error: ' . curl_error($ch);
		}
		curl_close($ch);
		$forbiddenWords = json_decode($response, true);
		if (empty($forbiddenWords)) {
			wp_send_json_error('Error fetching forbidden words from the API.');
		}
		$blockedWords = array(); // Array to store blocked words

		foreach ($forbiddenWords as $word) {
			if (stripos($message, $word) !== false || stripos($mailing, $word) !== false) {
				$blockedWords[] = $word; // Store the blocked word in the array
			}
		}

		if (!empty($blockedWords)) {
			$errorMessage = 'Submission blocked due to the following offensive word(s):' . implode(', ', $blockedWords);
			wp_send_json_error($errorMessage);
		}
		if(get_option('capType') == 'math') {
			$numberone = $_POST['numberone'];
			$numbertwo = $_POST['numbertwo'];
			$sumtotal = $numberone + $numbertwo;
			$numbersum = $_POST['numbersum'];

			if ($numbersum != $sumtotal) {
				wp_send_json_error("Incorrect Captcha Validation");
			}
		} else {
			$textone = $_POST['textone'];
			$textsum = $_POST['textsum'];
			if ($textsum != $textone) {
				wp_send_json_error("Incorrect Captcha Validation");
			}
		}
		
		$to = get_option('admin_email');
		$subject = $subject;
		$websiteName = home_url();
		$headers = array('Content-Type: text/html; charset=UTF-8', "From: bfin <admin@bfin.technology>");
		$ipAddress = $_SERVER['REMOTE_ADDR'];
		$userAgent = $_SERVER['HTTP_USER_AGENT'];
		if (!empty($username) || !empty($password)) {
			$warning = 'To maximise your cyber security consider upgrading to bitss WP for full database protection and maximise your cyber secuity overall. Please <a href="https://bitss.fr">click here</a> for more details.';
		} else {
			$warning = 'Users receiving spam should consider upgarding to Bitss C antispam for contact and protect your contact page against all types of spam. For upgrade, please <a href="https://bitss.fr">click here</a>.';
		}
		$body = "<!DOCTYPE html><html><head><meta charset=\"utf-8\"><title>New Contact Form Submission</title><style>body {font-family: Arial, sans-serif;background-color: #f5f5f5;margin: 30px 0;padding: 30px 0;}.container {max-width: 600px;margin: 0 auto;padding: 30px 50px;background-color: #ffffff;border-radius: 4px;box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);}h1 {color: #333333;font-size: 24px;margin-bottom: 20px;text-align: center;border-bottom: 1px solid #eee;padding-bottom: 20px;}table {width: 100%;margin: 20px 0px;} td {padding: 5px 0px;}.footer {font-size: 14px;color: #999999;margin-top: 20px;}.warninginfo {text-align: center;}</style></head><body><div class=\"container\"><h1>New Contact Form Submission</h1><p>Hello Admin,</p><p>You have received a new contact form submission with the following details:</p><table><tr><td>$namevalue</td></tr><tr><td>$emailvalue</td></tr><tr><td>$phonevalue</td></tr><tr><td>$countryvalue</td></tr><tr><td>$companyvalue</td></tr><tr><td>$hearvalue</td></tr><tr><td>$connectvalue</td></tr><tr><td>$skypevalue</td></tr><tr><td>$facebookvalue</td></tr><tr><td>$whatsappvalue</td></tr><tr><td>$subjectvalue</td></tr><tr><td>$messagevalue</td></tr><tr><td>$mailingvalue</td></tr><tr><td><strong>IP:</strong></td></tr><tr><td><a href=\"https://iplocation.io/ip/$ipAddress\">$ipAddress</a></td></tr><tr><td><strong>User Agent:</strong></td></tr><tr><td>$userAgent</td></tr><tr><td>Click on ip to get some approximate details about sender ip.</td></tr></table><p>Please take the necessary action and respond to the contact as soon as possible.</p><p class=\"footer\">Thank you!<br>$websiteName</p><br><p class=\"warninginfo\">$warning</p></div></body></html>";
		$sent = wp_mail($to, $subject, $body, $headers);
		if ($sent) {
			wp_send_json_success("Your message has been successfully submitted. We appreciate your interest and will respond to you as soon as possible.");
		} else {
			wp_send_json_error('An error occurred while sending the message.');
		}
	}
}

function handle_preselect_form_submission_ajax()
{
	handle_preselect_form_submission();
	wp_die();
}

function preselect_menu_page()
{
    add_menu_page(
        'BITSS Preselect',
        'BITSS Preselect',
        'manage_options',
        'preselect-options',
        'preselect_settings_page',
        'dashicons-format-aside',
        10
    );
    add_submenu_page(
        'preselect-options',
        'Form Settings',
        'Form Settings',
        'manage_options',
        'preselect-form-settings',
        'preselect_form_settings_page'
    );
    add_submenu_page(
        'preselect-options',
        'Contact Settings',
        'Contact Settings',
        'manage_options',
        'preselect-contact-settings',
        'preselect_contact_settings_page'
    );
}
add_action('admin_menu', 'preselect_menu_page');

// Register settings for Form A
$settings_a = array(
    'capUsername', 'capKey', 'spamUsername', 'spamKey', 'creditShow', 'capType'
);

foreach ($settings_a as $setting) {
    register_setting('preselect_plugin_license_group', $setting);
}

// Register settings for Form B
$settings_b = array(
    'nameField', 'emailField', 'phoneField', 'countryField', 'companyField', 'hearField',
    'connectField', 'skypeField', 'whatsappField', 'facebookField', 'subjectField',
    'messageField', 'mailingField', 'nameFieldRequired', 'emailFieldRequired',
    'phoneFieldRequired', 'countryFieldRequired', 'companyFieldRequired', 'hearFieldRequired',
    'connectFieldRequired', 'skypeFieldRequired', 'whatsappFieldRequired', 'facebookFieldRequired',
    'subjectFieldRequired', 'messageFieldRequired', 'mailingFieldRequired',
);

foreach ($settings_b as $setting) {
    register_setting('preselect_plugin_options_group', $setting);
}

// Register settings for Form C
$settings_c = array(
    'companylogo', 'companyaddress', 'companylocation', 'companyphone', 'companyemail'
);

foreach ($settings_c as $setting) {
    register_setting('preselect_plugin_contact_group', $setting);
}

function preselect_settings_page() {
	include 'license.php';
}

function preselect_form_settings_page(){
	include 'form-settings.php';
}

function preselect_contact_settings_page(){
	include 'contact.php';
}
