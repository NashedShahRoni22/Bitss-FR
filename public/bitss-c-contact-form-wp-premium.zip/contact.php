<div class="wrap">
	<h3>BITSS Preselect Contact Form Info Settings</h3>
	<form method="post" action="options.php">
		<?php
			settings_fields('preselect_plugin_contact_group');
			do_settings_sections('preselect_plugin_contact_group');
		?>
		<div class="card-holder">
			<div class="card-section">
				<h2>Enter your company details to show beside contact form</h2>
				<div class="mb10">
					<label for="companylogo" class="form-label">Logo URL:</label>
					<input type="text" name="companylogo" id="companylogo" value="<?php echo esc_attr(get_option('companylogo')); ?>">
					<small style="color:#f90000">Note: Load image if required prior and then collect logo url from website admin section media library.</small>
				</div>
				<div class="mb10">
					<label for="companyaddress" class="form-label">Address:</label>
					<textarea name="companyaddress" id="companyaddress" rows="4" class="form-label"><?php echo esc_attr(get_option('companyaddress')); ?></textarea>
				</div>
				<div class="mb10">
					<label for="companylocation" class="form-label">Location (Google map embeded code only):</label>
					<textarea name="companylocation" id="companylocation" rows="4" class="form-label"><?php echo esc_attr(get_option('companylocation')); ?></textarea>
				</div>
				<div class="mb10">
					<label for="companyphone" class="form-label">Phone:</label>
					<input type="text" name="companyphone" id="companyphone" value="<?php echo esc_attr(get_option('companyphone')); ?>">
				</div>
				<div class="mb10">
					<label for="companyemail" class="form-label">Email:</label>
					<input type="text" name="companyemail" id="companyemail" value="<?php echo esc_attr(get_option('companyemail')); ?>">
				</div>
			</div>
		</div>
								
		<div class="button-submit">
			<?php
			submit_button('Save Settings');
			?>
		</div>
	</form>
</div>