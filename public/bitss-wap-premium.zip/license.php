<?php

add_action('admin_menu', function() {
    add_menu_page(
        'Bitss Wap Settings', //page title
        'Bitss Wap', //menu title
        'manage_options', //capability
        'bitss-settings', //menu slug
        'bitss_settings', //callback function
        'dashicons-privacy', //icon_url
        10 //position
    );
    add_submenu_page(
        'bitss-settings',
        'Bitss Wap Settings', //page title
        'Settings', //menu title
        'manage_options', //capability
        'bitss-settings', //menu slug
        'bitss_settings' //callback function
    );
});

add_action('admin_init', function() {
    register_setting('bitss-settings-group', 'ipsum_threat');
});

function bitss_settings() {
    ?>
    <div class="wrap">
        <h1>Bitss Wap Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('bitss-settings-group');
            do_settings_sections('bitss-settings-group');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Disable Lost Password</th>
                    <td>
                        <input type="checkbox" name="disable_lost_password" value="1" <?php checked(1, get_option('disable_lost_password'), true); ?> />
                        <label for="disable_lost_password">Check to disable the lost password functionality</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Enable IPsum Threat Protection</th>
                    <td>
                        <input type="checkbox" name="ipsum_threat" value="1" <?php checked(1, get_option('ipsum_threat'), true); ?> />
                        <label for="ipsum_threat">Check to enable IPsum Threat Protection functionality to block the ip based on that list.</label>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}