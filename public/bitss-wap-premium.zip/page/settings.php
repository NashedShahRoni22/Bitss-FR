<?php
/**
 * BITSS WAP for WordPress
 * Powered by BFINIT Ltd.
 * Author: BITSS Team
 * Maintain by: M Rahman Sayed
 * URL: https://github.com/mrahmansayed
 */

if ($license && isset($license['valid_till'])) {
	// Create DateTime objects for comparison
	$valid_till_date = new DateTime($license['valid_till']);
	$current_date = new DateTime();

	// Compare the current date with the valid_till date
	if ($current_date > $valid_till_date) {
		// Show warning if the current date is newer than the valid_till date
		function bitss_settings() { ?>
			<div class="wrap">
				<div class="notice notice-warning notice-alt"><p>Warning: Your license has expired! Your site might at risk. Please renew your license to avoid any issue. Thanks. Visit <a href="https://bitss.fr">bitss.fr</a> for details.</p></div>
				<h1>Bitss Wap Settings</h1>
				<form method="post" action="options.php">
					<?php
					settings_fields('bitss-settings-group');
					do_settings_sections('bitss-settings-group');
					?>
					<table class="form-table">
						<tr valign="top">
							<th scope="row">Username</th>
							<td>
								<input type="text" name="bitss_username" value="<?php echo esc_attr(get_option('bitss_username')); ?>" />
							</td>
						</tr>
						<tr valign="top">
							<th scope="row">License Key</th>
							<td>
								<input type="text" name="bitss_key" value="<?php echo esc_attr(get_option('bitss_key')); ?>" />
							</td>
						</tr>       
					</table>
					<?php submit_button(); ?>
				</form>
			</div>
		<?php }
	} else {
		// Execute some function if the license is still valid
		function bitss_settings() {
			?>
			<div class="wrap">
				<h1>Bitss Wap Settings</h1>
				<form method="post" action="options.php">
					<?php
					settings_fields('bitss-settings-group');
					do_settings_sections('bitss-settings-group');
					?>
					<table class="form-table">
						<tr valign="top">
							<th scope="row">Username</th>
							<td>
								<input type="text" name="bitss_username" value="<?php echo esc_attr(get_option('bitss_username')); ?>" />
							</td>
						</tr>
						<tr valign="top">
							<th scope="row">License Key</th>
							<td>
								<input type="text" name="bitss_key" value="<?php echo esc_attr(get_option('bitss_key')); ?>" />
							</td>
						</tr>
						<tr valign="top">
							<th scope="row">Disable Lost Password</th>
							<td>
								<input type="checkbox" name="disable_lost_password" value="1" <?php checked(1, get_option('disable_lost_password'), true); ?> />
								<label for="disable_lost_password">Check to disable the lost password functionality</label>
							</td>
						</tr>
						<tr valign="top">
							<th scope="row">Enable IPsum Threat Protection</th>
							<td>
								<input type="checkbox" name="ipsum_threat" value="1" <?php checked(1, get_option('ipsum_threat'), true); ?> />
								<label for="ipsum_threat">Check to enable IPsum Threat Protection functionality to block the ip based on that list.</label>
							</td>
						</tr>            
					</table>
					<?php submit_button(); ?>
				</form>
			</div>
			<?php
		}
	}
} else {
	function bitss_settings() { ?>
		<div class="wrap">
			<div class="notice notice-error notice-alt"><p>Invalid license data. Please check license to avoid any issue. Thanks. Visit <a href="https://bitss.fr">bitss.fr</a> for details.</p></div>
			<h1>Bitss Wap Settings</h1>
			<form method="post" action="options.php">
				<?php
				settings_fields('bitss-settings-group');
				do_settings_sections('bitss-settings-group');
				?>
				<table class="form-table">
					<tr valign="top">
						<th scope="row">Username</th>
						<td>
							<input type="text" name="bitss_username" value="<?php echo esc_attr(get_option('bitss_username')); ?>" />
						</td>
					</tr>
					<tr valign="top">
						<th scope="row">License Key</th>
						<td>
							<input type="text" name="bitss_key" value="<?php echo esc_attr(get_option('bitss_key')); ?>" />
						</td>
					</tr>       
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
	<?php }
}

add_action('admin_init', function() {
    register_setting('bitss-settings-group', 'disable_lost_password');
    register_setting('bitss-settings-group', 'ipsum_threat');
    register_setting('bitss-settings-group', 'bitss_username');
    register_setting('bitss-settings-group', 'bitss_key');
});