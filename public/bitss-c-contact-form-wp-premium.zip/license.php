<div class="wrap">
	<h3>BITSS Preselect Contact Form License Settings</h3>
	<div class="custom-notice notice-red">
		<p><strong>Note:</strong> Without license you can easily use contact form. To use this form use our shortcode <strong>[bitss_preselect_form]</strong> in your template. If you put any invalid key or username, it won't show any error but may occur in contact form performance. Thanks.</p>
	</div>

	<div class="custom-notice notice-yellow">
		<p>Please make sure that, you use correct license key for CAPTCHA or Spamming Block section. Don't try to use single license in both field. It may occur issue.</p>
	</div>

	<form method="post" action="options.php">
		<?php
			settings_fields('preselect_plugin_license_group');
			do_settings_sections('preselect_plugin_license_group');
		?>
		<div class="card-holder">
			<div class="card-section">
				<h2>CAPTCHA License</h2>
				<div class="mb10">
					<label for="capUsername" class="form-label">License Username:</label>
					<input type="text" name="capUsername" id="capUsername" value="<?php echo esc_attr(get_option('capUsername')); ?>">
				</div>
				<div class="mb10">
					<label for="capKey" class="form-label">License Key:</label>
					<input type="text" name="capKey" id="capKey" value="<?php echo esc_attr(get_option('capKey')); ?>">
				</div>
			</div>
			
			<div class="card-section">
				<h2>Spamming Block License</h2>
				<div class="mb10">
					<label for="spamUsername" class="form-label">License Username:</label>
					<input type="text" name="spamUsername" id="spamUsername" value="<?php echo esc_attr(get_option('spamUsername')); ?>">
				</div>
				<div class="mb10">
					<label for="spamKey" class="form-label">License Key:</label>
					<input type="text" name="spamKey" id="spamKey" value="<?php echo esc_attr(get_option('spamKey')); ?>">
				</div>
			</div>
			<div class="card-section">
				<div class="mb10">
					<input class="form-check-input" name="creditShow" type="checkbox" value="1" id="creditShow" <?php checked(get_option('creditShow'), 1); ?>>
					<label class="form-check-label" for="creditShow">
						Would you like to display the "Powered by" message below?
					</label>
				</div>
			</div>
			<div class="card-section">
				<div class="mb10">
					<label for="capType" class="form-label">Choose your BITSS captcha: (
					<small>
						<?php
							if (get_option('capType') == 'math') {
								echo 'Math Based Selected';
							} else {
								echo 'Random Text Based Selected';
							}
						?>
					</small> )
					</label>
                    <select id="capType" name="capType">
                        <option value="math">Math Based</option>
                        <option value="text">Random Text Based</option>
                    </select>
				</div>
			</div>
		</div>
								
		<div class="button-submit">
			<?php
			submit_button('Save Settings');
			?>
		</div>
	</form>
</div>